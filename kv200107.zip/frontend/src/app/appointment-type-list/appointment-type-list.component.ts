import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppointmentTypeService } from '../services/appointment-type.service';
import { AppointmentType } from '../models/appointmentType';
import { Specialization } from '../models/specialization';
import { SpecializationService } from '../services/specialization.service';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-appointment-type-list',
  templateUrl: './appointment-type-list.component.html',
  styleUrls: ['./appointment-type-list.component.css']
})
export class AppointmentTypeListComponent implements OnInit {

  constructor(private router: Router, private appointmentTypeService: AppointmentTypeService, private specializationService: SpecializationService, private userService: UserService) { }

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    if(this.loggedIn != "admin") {
      this.router.navigate(['']);
      return;
    }
    this.userService.updateNavbar("admin");

    this.specializationService.getAllSpecializations().subscribe((specializationsFromDB: Specialization[])=>{
      if(specializationsFromDB.length == 0) this.message = "Nema specijalizacija"
      this.specializations = specializationsFromDB;
    })
  }

  loggedIn: string;
  message: string;

  specializations: Specialization[];
  appointmentTypes: AppointmentType[];

  chosenSpecialization: boolean = false;
  hasAppointmentTypes: boolean = false;
  specialization: string;

  updateSpecialization(e){
    this.chosenSpecialization = true;
    this.specialization = e.target.value.substring(3);
    this.appointmentTypeService.getAllAppointmentTypesForSpecialization(this.specialization).subscribe((AppointmentTypesFromDB: AppointmentType[])=>{
      if(AppointmentTypesFromDB.length == 0) {
        this.message = "Nema pregleda za ovu specijalizaciju";
        this.hasAppointmentTypes = false;
      }
      else {
        this.message = ""
        this.hasAppointmentTypes = true;
      }
      this.appointmentTypes = AppointmentTypesFromDB;
    })
  }

  editAppointmentType(name, length, price){
    sessionStorage.setItem("atNameForEdit", name);
    sessionStorage.setItem("atLengthForEdit", length);
    sessionStorage.setItem("atPriceForEdit", price);
    this.router.navigate(['edit_appointment_type']);
  }

  deleteAppointmentType(name){
    const data = {
      "name": name
    }
    this.appointmentTypeService.deleteAppointmentType(data).subscribe(respObj=>{
      if(respObj['message']=="ok"){
        alert("Uspesno izbrisana vrsta pregleda")
        window.location.reload();
      }
      else {
        this.message = "Greska pri brisanju vrste pregleda"
      }
    })
  }

}
