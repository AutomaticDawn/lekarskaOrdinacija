export class User{
    type: number;
    username: string;
    password: string;
    firstname: string;
    lastname: string;
    address: string;
    phone_number: string;
    email: string;
    pfp: string;
    license_number: string;
    specialization: string;
    department: string;
    approved: boolean;
    appointment_types: Array<String>
}