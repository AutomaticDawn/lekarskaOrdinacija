export class Appointment{
    patient: string;
    patient_firstname: string;
    patient_lastname: string;
    doctor: string;
    doctor_firstname: string;
    doctor_lastname: string;
    appointment_type: string;
    department: string;
    start_date_and_time: Date;
    end_date_and_time: Date;
    performed: boolean;
    canceled: boolean;
}