export class Notification{
    username: string;
    title: string;
    content: string;
    date: Date;
    viewed: boolean;
}