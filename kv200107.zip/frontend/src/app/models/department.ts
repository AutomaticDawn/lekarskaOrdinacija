export class Department{
    name: string;
}