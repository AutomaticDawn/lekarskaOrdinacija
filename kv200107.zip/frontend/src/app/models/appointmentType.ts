export class AppointmentType{
    name: string;
    length: string;
    price: string;
    specialization: string;
    approved: boolean;
    deleted: boolean;
}