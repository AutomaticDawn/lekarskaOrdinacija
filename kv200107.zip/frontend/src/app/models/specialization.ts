export class Specialization{
    name: string;
}