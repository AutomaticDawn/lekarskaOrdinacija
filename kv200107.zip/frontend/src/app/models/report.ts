export class Report{
    patient: string;
    doctor: string;
    date_and_time_of_appointment: Date;
    doctor_name: string;
    doctor_specialization: string;
    reason_for_appointment: string;
    diagnosis: string;
    recommended_therapy: string;
    next_appointment_recommended_date: Date;
}