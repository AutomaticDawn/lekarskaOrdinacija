import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  constructor(private router: Router, private userService: UserService) { }

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    if(this.loggedIn == "admin"){
      this.admin = true;
    }
    else if(this.loggedIn == "patient" || this.loggedIn == "doctor"){
      this.admin = false;
    }
    else {
      this.admin = false;
      this.router.navigate(['']);
      return;
    }

    this.username = sessionStorage.getItem("username");
  }

  admin: boolean;
  loggedIn: string;
  username: string;
  oldPassword: string;
  newPassword: string; 
  confirmPassword: string;

  message: string;

  backToProfile(){
    this.router.navigate(['user']);
  }

  changePassword(){
    const data = {
      "username": this.username,
      "oldPassword": this.oldPassword,
      "newPassword": this.newPassword
    }
    this.userService.changePassword(data).subscribe(respObj=>{
      if(respObj['message']=="ok"){
        this.message = "";
        alert("Promena lozinke uspesna");
        sessionStorage.clear();
        this.userService.updateNavbar("false");
        this.router.navigate(['']);
      }
      else{
        this.message = "Greska pri promeni lozinke"
      }
    })
  }

}
