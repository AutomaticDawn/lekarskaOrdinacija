import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';
import { UserComponent } from './user/user.component';
import { AdminComponent } from './admin/admin.component';
import { HomeComponent } from './home/home.component';
import { RegisterPatientComponent } from './register-patient/register-patient.component';
import { GalleryComponent } from './gallery/gallery.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LoginManagerComponent } from './login-manager/login-manager.component';
import { RegisterSuccessComponent } from './register-success/register-success.component';
import { RegisterDoctorComponent } from './register-doctor/register-doctor.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { EditUserComponent } from './edit-user/edit-user.component';
import { EditPfpComponent } from './edit-pfp/edit-pfp.component';
import { AddSpecializationComponent } from './add-specialization/add-specialization.component';
import { PatientRequestsComponent } from './patient-requests/patient-requests.component';
import { PatientListComponent } from './patient-list/patient-list.component';
import { DoctorListComponent } from './doctor-list/doctor-list.component';
import { SearchDoctorsComponent } from './search-doctors/search-doctors.component';
import { OtherComponent } from './other/other.component';
import { RequestNewAppointmentTypeComponent } from './request-new-appointment-type/request-new-appointment-type.component';
import { AppointmentTypeRequestsComponent } from './appointment-type-requests/appointment-type-requests.component';
import { AppointmentTypeListComponent } from './appointment-type-list/appointment-type-list.component';
import { EditAppointmentTypeComponent } from './edit-appointment-type/edit-appointment-type.component';
import { ChooseAppointmentTypesComponent } from './choose-appointment-types/choose-appointment-types.component';
import { ScheduleAppointmentFormComponent } from './schedule-appointment-form/schedule-appointment-form.component';
import { SetFreeDaysComponent } from './set-free-days/set-free-days.component';
import { AppointmentsPatientComponent } from './appointments-patient/appointments-patient.component';
import { AppointmentsDoctorComponent } from './appointments-doctor/appointments-doctor.component';
import { PatientRecordComponent } from './patient-record/patient-record.component';
import { SubmitReportComponent } from './submit-report/submit-report.component';
import { ViewReportComponent } from './view-report/view-report.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { BnNgIdleService } from 'bn-ng-idle';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    LoginComponent,
    UserComponent,
    AdminComponent,
    HomeComponent,
    RegisterPatientComponent,
    GalleryComponent,
    LoginManagerComponent,
    RegisterSuccessComponent,
    RegisterDoctorComponent,
    ChangePasswordComponent,
    EditUserComponent,
    EditPfpComponent,
    AddSpecializationComponent,
    PatientRequestsComponent,
    PatientListComponent,
    DoctorListComponent,
    SearchDoctorsComponent,
    OtherComponent,
    RequestNewAppointmentTypeComponent,
    AppointmentTypeRequestsComponent,
    AppointmentTypeListComponent,
    EditAppointmentTypeComponent,
    ChooseAppointmentTypesComponent,
    ScheduleAppointmentFormComponent,
    SetFreeDaysComponent,
    AppointmentsPatientComponent,
    AppointmentsDoctorComponent,
    PatientRecordComponent,
    SubmitReportComponent,
    ViewReportComponent,
    NotificationsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [BnNgIdleService],
  bootstrap: [AppComponent]
})
export class AppModule { }
