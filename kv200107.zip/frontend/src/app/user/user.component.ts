import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';
import { User } from '../models/user';
import { AppointmentType } from '../models/appointmentType';
import { AppointmentTypeService } from '../services/appointment-type.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  constructor(private router: Router, private userService: UserService, private appointmentTypeService: AppointmentTypeService) { }

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    if(this.loggedIn == "patient"){
      let usernameForDoctorView = sessionStorage.getItem("usernameForPatient");
      if(usernameForDoctorView == null || usernameForDoctorView == "false"){
        this.patientViewingDoctorProfile = false;
        this.adminViewingProfile = false;
        this.doctorProfile = false;
        this.doctorView = false;
        this.username = sessionStorage.getItem("username");
        this.firstname = sessionStorage.getItem("firstname");
        this.lastname = sessionStorage.getItem("lastname");
        this.address = sessionStorage.getItem("address");
        this.email = sessionStorage.getItem("email");
        this.phone_number = sessionStorage.getItem("phone_number");
        this.pfp = sessionStorage.getItem("pfp");
      }
      else {
        this.userService.getDoctorInfo(usernameForDoctorView).subscribe((UserFromDB: User)=>{
          this.patientViewingDoctorProfile = true;
          this.adminViewingProfile = false;
          this.doctorProfile = false;
          this.doctorView = false;
          this.type = UserFromDB.type;
          this.username = UserFromDB.username;
          this.firstname = UserFromDB.firstname;
          this.lastname = UserFromDB.lastname;
          this.address = UserFromDB.address;
          this.email = UserFromDB.email;
          this.phone_number = UserFromDB.phone_number;
          this.pfp = UserFromDB.pfp;
          this.license_number = UserFromDB.license_number;
          this.specialization = UserFromDB.specialization;
          this.department = UserFromDB.department;
          this.ATs = UserFromDB.appointment_types;

          const data = {
            "appointment_types": this.ATs
          }
          this.appointmentTypeService.getAppointmentTypes(data).subscribe((ATsFromDB: AppointmentType[])=>{
            if(ATsFromDB.length == 0) this.message = "Doktor trenutno ne drzi preglede"
            this.appointmentTypes = ATsFromDB;
          })
        })
      }
    }
    else if(this.loggedIn == "doctor"){
      this.patientViewingDoctorProfile = false;
      this.adminViewingProfile = false;
      this.doctorProfile = true;
      this.doctorView = true;
      this.username = sessionStorage.getItem("username");
      this.firstname = sessionStorage.getItem("firstname");
      this.lastname = sessionStorage.getItem("lastname");
      this.address = sessionStorage.getItem("address");
      this.email = sessionStorage.getItem("email");
      this.phone_number = sessionStorage.getItem("phone_number");
      this.pfp = sessionStorage.getItem("pfp");
      this.license_number = sessionStorage.getItem("license_number");
      this.specialization = sessionStorage.getItem("specialization");
      this.department = sessionStorage.getItem("department");
    }
    else if(this.loggedIn == "admin"){
      let usernameForAdmin = sessionStorage.getItem("usernameForAdmin")
      let typeForAdmin = sessionStorage.getItem("typeForAdmin");
      if(typeForAdmin == "1"){
        this.userService.getDoctorInfo(usernameForAdmin).subscribe((UserFromDB: User)=>{
          this.patientViewingDoctorProfile = false;
          this.adminViewingProfile = true;
          this.doctorProfile = true;
          this.doctorView = false;
          this.type = UserFromDB.type;
          this.username = UserFromDB.username;
          this.firstname = UserFromDB.firstname;
          this.lastname = UserFromDB.lastname;
          this.address = UserFromDB.address;
          this.email = UserFromDB.email;
          this.phone_number = UserFromDB.phone_number;
          this.pfp = UserFromDB.pfp;
          this.license_number = UserFromDB.license_number;
          this.specialization = UserFromDB.specialization;
          this.department = UserFromDB.department;
        })
      }
      else if(typeForAdmin == "2"){
        this.userService.getPatientInfo(usernameForAdmin).subscribe((UserFromDB: User)=>{
          this.adminViewingPatient = true;
          this.patientViewingDoctorProfile = false;
          this.adminViewingProfile = true;
          this.doctorProfile = true;
          this.doctorView = false;
          this.type = UserFromDB.type;
          this.username = UserFromDB.username;
          this.firstname = UserFromDB.firstname;
          this.lastname = UserFromDB.lastname;
          this.address = UserFromDB.address;
          this.email = UserFromDB.email;
          this.phone_number = UserFromDB.phone_number;
          this.pfp = UserFromDB.pfp;
          this.license_number = UserFromDB.license_number;
          this.specialization = UserFromDB.specialization;
          this.department = UserFromDB.department;
        })
      }
    }
    else{
      this.router.navigate(['']);
      return;
    }
  }

  patientViewingDoctorProfile: boolean = false;
  adminViewingPatient: boolean = false;
  adminViewingProfile: boolean = false;
  doctorProfile: boolean = false;
  doctorView: boolean = false;
  loggedIn: string;
  message: string = "";

  type: number;
  username: string;
  firstname: string;
  lastname: string;
  address: string;
  email: string;
  phone_number: string;
  pfp: string;
  license_number: string;
  specialization: string;
  department: string;
  ATs: Array<String>;

  appointmentTypes: AppointmentType[];

  changePassword(){
    this.router.navigate(['change_password']);
  }

  editInfo(){
    if(this.type == 2) sessionStorage.setItem("typeForAdmin", "2")
    else if (this.type == 1) sessionStorage.setItem("typeForAdmin", "1");
    
    this.router.navigate(['edit_user']);
  }

  editPfp(){
    sessionStorage.setItem("usernameForAdmin", this.username)
    this.router.navigate(['edit_pfp']);
  }

  chooseAppointmentTypes(){
    this.router.navigate(['choose_appointment_types']);
  }

  backToPatientsForAdmin(){
    this.userService.updateNavbar("admin");
    if(this.type==1){
      this.router.navigate(['doctor_list']);
    }
    else{
      this.router.navigate(['patient_list']);
    }
  }

  backToDoctorSearch(){
    this.userService.updateNavbar("patient");
    this.router.navigate([sessionStorage.getItem("patientReturnRoute")]);
  }

  //Zakazivanje pregleda
  prepForScheduling(atName, atLength){
    sessionStorage.setItem("patientUsername", sessionStorage.getItem("username"));
    sessionStorage.setItem("doctorUsername", this.username);
    sessionStorage.setItem("appointmentTypeName", atName);
    sessionStorage.setItem("appointmentTypeLength", atLength);
    sessionStorage.setItem("doctorDepartment", this.department)
  }

  scheduleAppointmentOverForm(atName, atLength){
    this.prepForScheduling(atName, atLength);
    this.router.navigate(['schedule_appointment_form'])
  }

  scheduleAppointmentOverCalendar(atName, atLength){

  }

}
