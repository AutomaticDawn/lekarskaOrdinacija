import { Component, OnInit } from '@angular/core';
import { ReportService } from '../services/report.service';
import { Router } from '@angular/router';
import { Report } from '../models/report';
import { UserService } from '../services/user.service';
import { User } from '../models/user';

@Component({
  selector: 'app-view-report',
  templateUrl: './view-report.component.html',
  styleUrls: ['./view-report.component.css']
})
export class ViewReportComponent implements OnInit {

  constructor(private router: Router, private reportService: ReportService, private userService: UserService) { }

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    if(this.loggedIn == "doctor"){
      this.doctorView = true;
      this.patientView = false;
    }
    else if(this.loggedIn == "patient"){
      this.doctorView = false;
      this.patientView = true;
    }
    else{
      this.router.navigate(['']);
      return
    }

    let patientUsername = sessionStorage.getItem("patientForReport")
    let doctorUsername = sessionStorage.getItem("doctorForReport");
    let date_and_time_of_appointment = JSON.parse(sessionStorage.getItem("dateAndTimeOfAppointmentForReport"))['date'];

    const data = {
      "patient": patientUsername,
      "doctor": doctorUsername,
      "date_and_time_of_appointment": date_and_time_of_appointment
    }

    this.reportService.getReport(data).subscribe((reportFromDB: Report)=>{
      if(reportFromDB == null) this.message = "Greska pri dohvatanju izvestaja"
      this.report = reportFromDB;
    })

    this.userService.getPatientInfo(patientUsername).subscribe((patientFromDB: User)=>{
      if(patientFromDB == null) this.message = "Greska pri dohvatanju pacijenta"
      this.patient = patientFromDB;
    })
  }

  loggedIn: string;
  message: string;

  doctorView: boolean
  patientView: boolean

  patient: User
  report: Report

  date_and_time_of_appointment: Date;
  doctor_name: string;
  doctor_specialization: string;
  reason_for_appointment: string;
  diagnosis: string;
  recommended_therapy: string;
  next_appointment_recommended_date: Date;

  back(){
    if(this.doctorView) this.router.navigate(['patient_record']);
    else if(this.patientView) this.router.navigate(['appointments_patient']);
  }

}
