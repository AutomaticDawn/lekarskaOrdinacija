import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';
import { User } from '../models/user';

@Component({
  selector: 'app-patient-requests',
  templateUrl: './patient-requests.component.html',
  styleUrls: ['./patient-requests.component.css']
})
export class PatientRequestsComponent implements OnInit {

  constructor(private router: Router, private userService: UserService) { }

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    if(this.loggedIn != "admin") {
      this.router.navigate(['']);
      return;
    }

    this.userService.getAllUnapprovedPatients().subscribe((patientsFromDB: User[])=>{
      if(patientsFromDB.length == 0) this.message = "Nema zahteva za nove pacijente"
      this.unapprovedPatients = patientsFromDB;
    })
  }

  loggedIn: string;
  message: string;

  unapprovedPatients: User[];

  approve(username){
    this.message = ""
    const data = {
      "username": username
    }
    this.userService.approveNewPatient(data).subscribe(respObj=>{
      if(respObj['message']=="ok"){
        alert("Korisnik uspesno odobren")
        //this.message = "approved " + username;
        this.ngOnInit();
      }
      else this.message = "Greska pri odobravanju korisnika"
    })
    
  }

  disapprove(username){
    this.message = ""
    const data = {
      "username": username
    }
    this.userService.denyNewPatient(data).subscribe(respObj=>{
      if(respObj['message']=="ok"){
        alert("Korisnik uspesno odbijen")
        //this.message = "disapproved " + username;
        this.ngOnInit();
      }
      else this.message = "Greska pri odbijanju korisnika"
    })
  }

}
