import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-set-free-days',
  templateUrl: './set-free-days.component.html',
  styleUrls: ['./set-free-days.component.css']
})
export class SetFreeDaysComponent implements OnInit {

  constructor(private router: Router, private userService: UserService) { }

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    if(this.loggedIn != "doctor"){
      this.router.navigate(['']);
      return;
    }
  }

  loggedIn: string;
  message: string;

  goBackToOther(){
    this.router.navigate(['other']);
  }

}
