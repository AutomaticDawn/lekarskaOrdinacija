import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SetFreeDaysComponent } from './set-free-days.component';

describe('SetFreeDaysComponent', () => {
  let component: SetFreeDaysComponent;
  let fixture: ComponentFixture<SetFreeDaysComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SetFreeDaysComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SetFreeDaysComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
