import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';
import { AppointmentTypeService } from '../services/appointment-type.service';
import { AppointmentType } from '../models/appointmentType';
import { User } from '../models/user';

@Component({
  selector: 'app-choose-appointment-types',
  templateUrl: './choose-appointment-types.component.html',
  styleUrls: ['./choose-appointment-types.component.css']
})
export class ChooseAppointmentTypesComponent implements OnInit {

  constructor(private router: Router, private userService: UserService, private appointmentTypeService: AppointmentTypeService) { }

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    if(this.loggedIn != "doctor") {
      this.router.navigate(['']);
      return;
    }
    this.userService.updateNavbar("doctor");

    this.username = sessionStorage.getItem("username");
    this.specialization = sessionStorage.getItem("specialization");

    //dohvatanje svih vrsta pregleda
    this.appointmentTypeService.getAllAppointmentTypesForSpecialization(this.specialization).subscribe((atFromDB: AppointmentType[])=>{
      if(atFromDB.length == 0) {
        this.message = "Nema vrsta pregleda za specijalizaciju " + this.specialization;
      }
      this.allAppointmentTypes = atFromDB;

      //dohvatanje podataka o doktoru
      this.userService.getDoctorInfo(this.username).subscribe((doctorFromDB: User)=>{
        
        if(doctorFromDB == null) this.message = "Greska pri dohvatanju doktora";
        this.doctor = doctorFromDB;

        //setovanje trenutnih vrsta pregleda
        if(this.doctor.appointment_types.length == 0) this.hasCat = false;
        else this.hasCat = true;
        this.currentAppointmentTypes = this.doctor.appointment_types;

        this.allAppointmentTypes.forEach((at)=>{
          //this.message = this.message + " " + at.name + " ";

          let isInCurr = false;
          this.currentAppointmentTypes.forEach((cat)=>{
            if(at.name == cat){
              isInCurr = true;
            }
          })
          if(!isInCurr) this.notCurrentAppointmentTypes.push(at.name);
        })
    
        if(this.notCurrentAppointmentTypes.length == 0) this.hasNcat = false;
        else this.hasNcat = true;
      })
    })
  }

  loggedIn: string;
  message: string = "";

  doctor: User;
  username: string;
  specialization: string;

  hasNcat: boolean = false;
  hasCat: boolean = false;

  allAppointmentTypes: AppointmentType[];

  currentAppointmentTypes: Array<String> = [];
  notCurrentAppointmentTypes: Array<String> = [];

  backToProfile(){
    this.router.navigate(['user']);
  }

  removeAppointmentType(name){
    const index = this.currentAppointmentTypes.indexOf(name, 0);
    if (index > -1) {
      this.currentAppointmentTypes.splice(index, 1);
    }
    if(this.currentAppointmentTypes.length == 0) this.hasCat = false;

    this.notCurrentAppointmentTypes.push(name);
    this.hasNcat = true;

    const data = {
      "username": this.username,
      "new_appointment_types": this.currentAppointmentTypes
    }
    this.userService.updateAppointmentTypesForDoctor(data).subscribe(respObj=>{
      if(respObj['message']=="ok"){
        this.message = "Uspesno azurirani vrsti pregleda"
      }
      else{
        this.message = "Greska pri azuriranju vrsta pregleda"
      }
    })
  }

  addAppointmentType(name){
    const index = this.notCurrentAppointmentTypes.indexOf(name, 0);
    if (index > -1) {
      this.notCurrentAppointmentTypes.splice(index, 1);
    }
    if(this.notCurrentAppointmentTypes.length == 0) this.hasNcat = false;

    this.currentAppointmentTypes.push(name);
    this.hasCat = true;

    const data = {
      "username": this.username,
      "new_appointment_types": this.currentAppointmentTypes
    }
    this.userService.updateAppointmentTypesForDoctor(data).subscribe(respObj=>{
      if(respObj['message']=="ok"){
        this.message = "Uspesno azurirani vrsti pregleda"
      }
      else{
        this.message = "Greska pri azuriranju vrsta pregleda"
      }
    })
  }
}
