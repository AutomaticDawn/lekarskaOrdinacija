import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChooseAppointmentTypesComponent } from './choose-appointment-types.component';

describe('ChooseAppointmentTypesComponent', () => {
  let component: ChooseAppointmentTypesComponent;
  let fixture: ComponentFixture<ChooseAppointmentTypesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChooseAppointmentTypesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ChooseAppointmentTypesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
