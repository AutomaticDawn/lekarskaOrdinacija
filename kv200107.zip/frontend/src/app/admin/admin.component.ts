import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private router: Router, private userService: UserService) { }

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    if(this.loggedIn != "admin") {
      this.router.navigate(['']);
      return;
    }

    this.userService.updateNavbar("admin");
    this.username = sessionStorage.getItem("username");
  }

  loggedIn: string;
  message: string;

  username: string;

  changePassword(){
    this.router.navigate(['change_password']);
  }
}
