import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestNewAppointmentTypeComponent } from './request-new-appointment-type.component';

describe('RequestNewAppointmentTypeComponent', () => {
  let component: RequestNewAppointmentTypeComponent;
  let fixture: ComponentFixture<RequestNewAppointmentTypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RequestNewAppointmentTypeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RequestNewAppointmentTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
