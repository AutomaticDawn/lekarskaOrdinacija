import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SpecializationService } from '../services/specialization.service';
import { AppointmentTypeService } from '../services/appointment-type.service';
import { Specialization } from '../models/specialization';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-request-new-appointment-type',
  templateUrl: './request-new-appointment-type.component.html',
  styleUrls: ['./request-new-appointment-type.component.css']
})
export class RequestNewAppointmentTypeComponent implements OnInit {

  constructor(private router: Router, private specializationService: SpecializationService, private appointmentTypeService: AppointmentTypeService, private userService: UserService) { }

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    if(this.loggedIn == "admin"){
      this.admin = true;
      this.userService.updateNavbar("admin");
    }
    else if(this.loggedIn == "doctor"){
      this.admin = false;
      this.userService.updateNavbar("doctor")
    }
    else {
      this.router.navigate(['']);
    }
    

    this.specializationService.getAllSpecializations().subscribe((SpecializationsFromDB: Specialization[])=>{
      this.specializations = SpecializationsFromDB;
    })
  }

  admin: boolean;
  loggedIn: string;
  message: string;

  specializations: Specialization[];

  name: string;
  length: string;
  price: string;
  specialization: string = "";

  updateSpecialization(e){
    this.specialization = e.target.value.substring(3);
  }


  goBackToOther(){
    this.router.navigate(['other']);
  }

  submitRequest(){
    if(this.specialization == ""){
      this.message = "Izaberite specijalizaciju"
      return;
    }
    const data = {
      "name": this.name,
      "length": this.length,
      "price": this.price,
      "specialization": this.specialization
    }
    if(this.admin){
      this.appointmentTypeService.addNewAppointmentTypeApproved(data).subscribe(respObj=>{
        if(respObj['message']=="ok"){
          this.message = ""
          alert("Vrsta pregleda uspesno dodata");
          window.location.reload();
        }
        else{
          this.message = "Greska pri podnosenju zahteva za novu vrstu pregleda"
        }
      })
    }
    else{
      this.appointmentTypeService.addNewAppointmentTypeUnapproved(data).subscribe(respObj=>{
        if(respObj['message']=="ok"){
          this.message = ""
          alert("Zahtev uspesno podnet");
          this.router.navigate(['other']);
        }
        else{
          this.message = "Greska pri podnosenju zahteva za novu vrstu pregleda"
        }
      })
    }
  }
}
