import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';
import { SpecializationService } from '../services/specialization.service';
import { Specialization } from '../models/specialization';
import { DepartmentService } from '../services/department.service';
import { Department } from '../models/department';

@Component({
  selector: 'app-register-doctor',
  templateUrl: './register-doctor.component.html',
  styleUrls: ['./register-doctor.component.css']
})
export class RegisterDoctorComponent implements OnInit {

  constructor(private router: Router, private userService: UserService, private specializationService: SpecializationService, private departmentService: DepartmentService) { }

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    if(this.loggedIn != "admin") {
      this.router.navigate(['']);
      return;
    }

    this.specializationService.getAllSpecializations().subscribe((SpecializationsFromDB: Specialization[]) => {
      if(SpecializationsFromDB != null){
        this.specializations = SpecializationsFromDB;
      }
      else{
        this.message = "Greska pri dohvatanju specijalizacija"
      }
    });

    this.departmentService.getAllDepartments().subscribe((DepartmentsFromDB: Department[]) => {
      if(DepartmentsFromDB != null){
        this.departments = DepartmentsFromDB;
      }
      else{
        this.message = "Greska pri dohvatanju ogranaka"
      }
    });
  }

  loggedIn: string;
  message: string = "";

  username: string;
  password: string;
  confirmPassword: string;
  firstname: string;
  lastname: string;
  address: string;
  phone_number: string;
  email: string;
  license_number: string;
  specialization: string = "";
  department: string = "";

  profilePicture: File;
  invalidPfp: boolean = false;

  specializations: Specialization[];
  departments: Department[];

  updateSpecialization(e){
    this.specialization = e.target.value;
  }

  updateDepartment(e){
    this.department = e.target.value;
  }

  registerDoctor(){
    this.message = "";

    if(this.specialization == ""){
      this.message = "Specijalizacija nije izabrana"
      return;
    }

    if(this.department == ""){
      this.message = "Ogranak nije izabran"
      return;
    }

    let canRegister = true;
    this.userService.validateUsernameAndEmail(this.username, this.email).subscribe(respObj=>{
      if(respObj['usernameTaken']){
        this.message += " Korisnicko ime je vec uzeta."
        canRegister = false;
      }
      if(respObj['emailTaken']){
        this.message += " Email adresa je vec uzeta."
        canRegister = false;
      }

      this.specialization = this.specialization.substring(3);
      this.department = this.department.substring(3);

      let form = new FormData();
      form.append("username", this.username);
      form.append("password", this.password);
      form.append("firstname", this.firstname);
      form.append("lastname", this.lastname);
      form.append("address", this.address);
      form.append("phone_number", this.phone_number);
      form.append("email", this.email);
      form.append("pfp", this.profilePicture);
      form.append("license_number", this.license_number);
      form.append("specialization", this.specialization);
      form.append("department", this.department);

      if(canRegister){
        this.userService.registerDoctor(form).subscribe(respObj=>{
          if(respObj['message']=='ok') {
            alert("Doktor uspesno registrovan")
            this.message = 'Registracija uspesna';
            this.router.navigate(['register_doctor']);
          }
          else{
            this.message = 'Registracija neuspešna';
          }
        });
      }
    });
  }

  async isPfpValid(event:any) {
    if(event.target.value) {
      this.profilePicture = <File>event.target.files[0]
      let profilePicture = new Image();
      profilePicture.src = URL.createObjectURL(this.profilePicture);
      await profilePicture.decode();
      if(profilePicture.naturalWidth < 100 || profilePicture.naturalWidth > 300 || profilePicture.naturalHeight < 100 || profilePicture.naturalHeight > 300) this.invalidPfp = true;
      else this.invalidPfp = false;
    }
    else {
      this.invalidPfp = false;
      this.profilePicture = null;
    }
  }

}
