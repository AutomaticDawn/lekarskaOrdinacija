import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { BnNgIdleService } from 'bn-ng-idle';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {

  constructor(private userService: UserService, private router: Router, private bnNgIdleService: BnNgIdleService) { }

  ngOnInit(): void {
    //this.userService.currentLoggedIn.subscribe(message => this.message = message)
  }

  username: string;
  password: string;
  
  message: string = "";

  login(){
    this.userService.login(this.username, this.password).subscribe((userFromDB: User)=>{
      if(userFromDB!=null){
        if(!userFromDB.approved) {
          this.message = "User still not approved"
          return;
        }
        this.message = "";
        if(userFromDB.type==0){
          this.message="Neispravni podaci";
        }
        else{
          if(userFromDB.type == 1) {
            sessionStorage.setItem("loggedIn", "doctor");
            sessionStorage.setItem("license_number", userFromDB.license_number.toLocaleString());
            sessionStorage.setItem("specialization", userFromDB.specialization);
            sessionStorage.setItem("department", userFromDB.department);
            this.userService.updateNavbar("doctor")
          }
          else if(userFromDB.type == 2) {
            sessionStorage.setItem("loggedIn", "patient");
            this.userService.updateNavbar("patient");
            this.userService.updateCanSeeDoctorProfilesOnHome("true");
          }
          sessionStorage.setItem("username", userFromDB.username);
          sessionStorage.setItem("firstname", userFromDB.firstname);
          sessionStorage.setItem("lastname", userFromDB.lastname);
          sessionStorage.setItem("address", userFromDB.address);
          sessionStorage.setItem("phone_number", userFromDB.phone_number);
          sessionStorage.setItem("email", userFromDB.email);
          sessionStorage.setItem("pfp", userFromDB.pfp);
          
          //this.bnNgIdleService.resetTimer(5);

          this.bnNgIdleService.startWatching(900).subscribe((isTimedOut: boolean) => {
            if(isTimedOut){
              sessionStorage.clear();
              this.userService.updateNavbar("false");
              this.userService.updateCanSeeDoctorProfilesOnHome("false");
              this.router.navigate(['login']);
              this.bnNgIdleService.stopTimer();
              alert("Izlogovani ste zbog neaktivnosti")
            }
          })

          this.router.navigate(['']);
        }
      }
      else{
        this.message="Neispravni podaci";
      }
    })
  }

}
