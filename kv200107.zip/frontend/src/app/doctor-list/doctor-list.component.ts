import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-doctor-list',
  templateUrl: './doctor-list.component.html',
  styleUrls: ['./doctor-list.component.css']
})
export class DoctorListComponent implements OnInit {

  constructor(private router: Router, private userService: UserService) { }

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    if(this.loggedIn != "admin") {
      this.router.navigate(['']);
      return;
    }

    this.userService.getAllDoctors().subscribe((doctorsFromDB: User[])=>{
      if(doctorsFromDB.length == 0) this.message = "Nema doktora"
      this.doctors = doctorsFromDB;
    })
  }

  loggedIn: string;
  message: string;

  doctors: User[];

  viewProfile(username){
    sessionStorage.setItem("usernameForAdmin", username);
    sessionStorage.setItem("typeForAdmin", "1");
    this.router.navigate(['user']);
  }

  deleteUser(username){
    this.message = ""
    const data = {
      "username": username
    }
    this.userService.deleteUser(data).subscribe(respObj=>{
      if(respObj['message']=="ok"){
        alert("Korisnik uspesno izbrisan")
        this.ngOnInit();
      }
      else{
        this.message = "Greska pri brisanju korisnika"
      }
    })
  }

}
