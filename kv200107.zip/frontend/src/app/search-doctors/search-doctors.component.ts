import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { UserService } from '../services/user.service';

@Component({
  selector: 'search-doctors',
  templateUrl: './search-doctors.component.html',
  styleUrls: ['./search-doctors.component.css']
})
export class SearchDoctorsComponent implements OnInit {

  constructor(private router: Router, private userService: UserService) { }

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    if(this.loggedIn == "patient"){
      this.patientView = true;
    }
    else{
      this.patientView = false;
      if(this.router.url == "/search_doctors"){
        this.router.navigate(['']);
      }
    }

    this.userService.getAllDoctors().subscribe((doctorsFromDB: User[])=>{
      if(doctorsFromDB.length == 0) this.message = "Nema doktora"
      this.doctors = doctorsFromDB;
      this.initialDoctors = doctorsFromDB;
    })
    this.sorted = "unsorted"

    this.userService.currentCanSeeDoctorProfilesOnHome.subscribe(message => {
      if(message == "true"){
        this.patientView = true;
      }
      else{
        this.patientView = false;
      }
    })

    this.userService.updateCanSeeDoctorProfilesOnHome(this.loggedIn == "patient" ? "true" : "false");
  }

  patientView: boolean;
  loggedIn: string;
  message: string;

  doctors: User[];
  initialDoctors: User[];

  firstname: string = "";
  lastname: string = "";
  specialization: string = "";

  viewDoctorProfile(username: string){
    sessionStorage.setItem("usernameForPatient", username);
    
    sessionStorage.setItem("patientReturnRoute", this.router.url.substring(1))
    this.router.navigate(['user']);
  }

  searchDoctors(){
    const data = {
      "firstname": this.firstname,
      "lastname": this.lastname,
      "specialization": this.specialization
    }
    this.userService.searchDoctors(data).subscribe((DoctorsFromDB: User[])=>{
      if(DoctorsFromDB.length == 0) this.message = "Nema rezultata";
      else this.message = "";

      this.doctors = DoctorsFromDB;

      this.initialDoctors = DoctorsFromDB;
      this.sorted = "unsorted";
      this.sortedMessage = "Nesortirano";
    })
  }

  sorted: string = "unsorted";
  sortedMessage: string = "Nesortirano";

  unsort(){
    this.doctors = this.initialDoctors;
    this.sorted = "unsorted";
    this.sortedMessage = "Nesortirano";
  }

  sortByFirstname(){
    if(this.sorted == "firstname"){
      this.doctors = this.userService.sortUsersByFirstnameReverse(this.doctors);
      this.sorted = "firstnameReversed";
      this.sortedMessage = "Obrnuto sortirano po imenu"
    }
    else{
      this.doctors = this.userService.sortUsersByFirstname(this.doctors);
      this.sorted = "firstname"
      this.sortedMessage = "Sortirano po imenu"
    }
  }

  sortByLastname(){
    if(this.sorted == "lastname"){
      this.doctors = this.userService.sortUsersByLastnameReverse(this.doctors);
      this.sorted = "lastnameReversed";
      this.sortedMessage = "Obrnuto sortirano po prezimenu"
    }
    else{
      this.doctors = this.userService.sortUsersByLastname(this.doctors);
      this.sorted = "lastname"
      this.sortedMessage = "Sortirano po prezimenu"
    }
  }

  sortBySpecialization(){
    if(this.sorted == "specialization"){
      this.doctors = this.userService.sortUsersBySpecializationReverse(this.doctors);
      this.sorted = "specializationReversed";
      this.sortedMessage = "Obrnuto sortirano po specijalizaciji"
    }
    else{
      this.doctors = this.userService.sortUsersBySpecialization(this.doctors);
      this.sorted = "specialization"
      this.sortedMessage = "Sortirano po specijalizaciji"

    }
  }

  sortByDepartment(){
    if(this.sorted == "department"){
      this.doctors = this.userService.sortUsersByDepartmentReverse(this.doctors);
      this.sorted = "departmentReversed";
      this.sortedMessage = "Obrnuto sortirano po ogranku"
    }
    else{
      this.doctors = this.userService.sortUsersByDepartment(this.doctors);
      this.sorted = "department"
      this.sortedMessage = "Sortirano po ogranku"
    }
  }
}
