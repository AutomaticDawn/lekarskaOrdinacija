import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserComponent } from './user/user.component';
import { AdminComponent } from './admin/admin.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RegisterPatientComponent } from './register-patient/register-patient.component';
import { LoginManagerComponent } from './login-manager/login-manager.component';
import { RegisterSuccessComponent } from './register-success/register-success.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { EditUserComponent } from './edit-user/edit-user.component';
import { EditPfpComponent } from './edit-pfp/edit-pfp.component';
import { RegisterDoctorComponent } from './register-doctor/register-doctor.component';
import { AddSpecializationComponent } from './add-specialization/add-specialization.component';
import { PatientRequestsComponent } from './patient-requests/patient-requests.component';
import { PatientListComponent } from './patient-list/patient-list.component';
import { DoctorListComponent } from './doctor-list/doctor-list.component';
import { SearchDoctorsComponent } from './search-doctors/search-doctors.component';
import { OtherComponent } from './other/other.component';
import { RequestNewAppointmentTypeComponent } from './request-new-appointment-type/request-new-appointment-type.component';
import { AppointmentTypeRequestsComponent } from './appointment-type-requests/appointment-type-requests.component';
import { AppointmentTypeListComponent } from './appointment-type-list/appointment-type-list.component';
import { EditAppointmentTypeComponent } from './edit-appointment-type/edit-appointment-type.component';
import { ChooseAppointmentTypesComponent } from './choose-appointment-types/choose-appointment-types.component';
import { ScheduleAppointmentFormComponent } from './schedule-appointment-form/schedule-appointment-form.component';
import { SetFreeDaysComponent } from './set-free-days/set-free-days.component';
import { AppointmentsPatientComponent } from './appointments-patient/appointments-patient.component';
import { AppointmentsDoctorComponent } from './appointments-doctor/appointments-doctor.component';
import { PatientRecordComponent } from './patient-record/patient-record.component';
import { SubmitReportComponent } from './submit-report/submit-report.component';
import { ViewReportComponent } from './view-report/view-report.component';
import { NotificationsComponent } from './notifications/notifications.component';

const routes: Routes = [
  {path: "", component: HomeComponent},
  {path: "login", component: LoginComponent},
  {path: "register", component: RegisterPatientComponent},
  {path: "user", component: UserComponent},
  {path: "admin", component: AdminComponent},
  {path: "login_manager", component: LoginManagerComponent},
  {path: "register_success", component: RegisterSuccessComponent},
  {path: "change_password", component: ChangePasswordComponent},
  {path: "edit_user", component: EditUserComponent},
  {path: "edit_pfp", component: EditPfpComponent},
  {path: "register_doctor", component: RegisterDoctorComponent},
  {path: "add_specialization", component: AddSpecializationComponent},
  {path: "patient_requests", component: PatientRequestsComponent},
  {path: "patient_list", component: PatientListComponent},
  {path: "doctor_list", component: DoctorListComponent},
  {path: "search_doctors", component: SearchDoctorsComponent},
  {path: "other", component: OtherComponent},
  {path: "request_new_appointment_type", component: RequestNewAppointmentTypeComponent},
  {path: "appointment_type_requests", component: AppointmentTypeRequestsComponent},
  {path: "appointment_type_list", component: AppointmentTypeListComponent},
  {path: "edit_appointment_type", component: EditAppointmentTypeComponent},
  {path: "choose_appointment_types", component: ChooseAppointmentTypesComponent},
  {path: "schedule_appointment_form", component: ScheduleAppointmentFormComponent},
  {path: "set_free_days", component: SetFreeDaysComponent},
  {path: "appointments_patient", component: AppointmentsPatientComponent},
  {path: "appointments_doctor", component: AppointmentsDoctorComponent},
  {path: "patient_record", component: PatientRecordComponent},
  {path: "submit_report", component: SubmitReportComponent},
  {path: "view_report", component: ViewReportComponent},
  {path: "notifications", component: NotificationsComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
