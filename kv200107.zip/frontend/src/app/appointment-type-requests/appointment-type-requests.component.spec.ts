import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AppointmentTypeRequestsComponent } from './appointment-type-requests.component';

describe('AppointmentTypeRequestsComponent', () => {
  let component: AppointmentTypeRequestsComponent;
  let fixture: ComponentFixture<AppointmentTypeRequestsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AppointmentTypeRequestsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AppointmentTypeRequestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
