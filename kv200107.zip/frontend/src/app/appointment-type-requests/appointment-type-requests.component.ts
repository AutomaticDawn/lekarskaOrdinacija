import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppointmentTypeService } from '../services/appointment-type.service';
import { AppointmentType } from '../models/appointmentType';

@Component({
  selector: 'app-appointment-type-requests',
  templateUrl: './appointment-type-requests.component.html',
  styleUrls: ['./appointment-type-requests.component.css']
})
export class AppointmentTypeRequestsComponent implements OnInit {

  constructor(private router: Router, private appointmentTypeService: AppointmentTypeService) { }

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    if(this.loggedIn != "admin") {
      this.router.navigate(['']);
      return;
    }

    this.appointmentTypeService.getAllUnapprovedAppointmentTypes().subscribe((AppointementTypesFromDB: AppointmentType[])=>{
      if(AppointementTypesFromDB.length == 0) this.message = "Nema zahteva za nove vrste pregleda"
      this.appointmentTypeRequests = AppointementTypesFromDB;
    })
  }

  loggedIn: string;
  message: string;

  appointmentTypeRequests: AppointmentType[];

  approve(name){
    this.message = ""
    const data = {
      "name": name
    }
    this.appointmentTypeService.approveNewAppointmentType(data).subscribe(respObj=>{
      if(respObj['message']=="ok"){
        alert("Vrsta pregleda uspesno odobrena")
        //this.message = "approved " + name;
        this.ngOnInit();
      }
      else this.message = "Greska pri odobravanju vrste pregleda"
    })
    
  }

  disapprove(name){
    this.message = ""
    const data = {
      "name": name
    }
    this.appointmentTypeService.denyNewAppointmentType(data).subscribe(respObj=>{
      if(respObj['message']=="ok"){
        alert("Vrsta pregleda uspesno odbijena")
        //this.message = "disapproved " + name;
        this.ngOnInit();
      }
      else this.message = "Greska pri odbijanju vrste pregleda"
    })
  }

}
