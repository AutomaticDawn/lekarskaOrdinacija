import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditPfpComponent } from './edit-pfp.component';

describe('EditPfpComponent', () => {
  let component: EditPfpComponent;
  let fixture: ComponentFixture<EditPfpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditPfpComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditPfpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
