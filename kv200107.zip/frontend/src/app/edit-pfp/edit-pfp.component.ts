import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';
import { User } from '../models/user';

@Component({
  selector: 'app-edit-pfp',
  templateUrl: './edit-pfp.component.html',
  styleUrls: ['./edit-pfp.component.css']
})
export class EditPfpComponent implements OnInit {

  constructor(private router: Router, private userService: UserService) { }

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    if(this.loggedIn == "patient" || this.loggedIn == "doctor") {
      this.username = sessionStorage.getItem("username");
      this.currentPfp = sessionStorage.getItem("pfp");
    }
    else if(this.loggedIn == "admin"){
      let type = sessionStorage.getItem("typeForAdmin");
      let username = sessionStorage.getItem("usernameForAdmin")
      if(type == "2") {
        this.userService.getPatientInfo(username).subscribe((UserFromDB: User)=>{
          this.username = UserFromDB.username;
          this.currentPfp = UserFromDB.pfp;
        })
      }
      else if(type == "1") {
        this.userService.getDoctorInfo(username).subscribe((UserFromDB: User)=>{
          this.username = UserFromDB.username;
          this.currentPfp = UserFromDB.pfp;
        })
      }
      
    }
    else{
      this.router.navigate(['']);
      return;
    }
  }

  loggedIn: string;
  username: string;
  currentPfp: string;

  profilePicture: File;
  invalidPfp: boolean;
  selectedPfp: boolean = false;

  message: string;

  backToProfile(){
    this.router.navigate(['user']);
  }

  editPfp(){
    let form = new FormData();
    
    form.append("username", this.username);
    form.append("pfp", this.profilePicture);

    if(this.profilePicture == null){
      this.message = "Molim vas izaberite sliku";
      return;
    }

    this.userService.editPfp(form).subscribe(respObj=>{
      if(respObj['message']=="ok"){
        sessionStorage.setItem("pfp", respObj['newPfpName']);

        this.message = ""
        alert("Profilna slika uspesno promenjena")
        this.userService.updateNavbar(this.loggedIn)
        this.router.navigate(['user']);
      }
      else{
        this.message = "Greska pri promeni profilne slike"
      }
    })
  }

  async isPfpValid(event:any) {
    if(event.target.value) {
      this.profilePicture = <File>event.target.files[0]
      let profilePicture = new Image();
      profilePicture.src = URL.createObjectURL(this.profilePicture);
      await profilePicture.decode();
      if(profilePicture.naturalWidth < 100 || profilePicture.naturalWidth > 300 || profilePicture.naturalHeight < 100 || profilePicture.naturalHeight > 300) {
        this.invalidPfp = true;
        this.selectedPfp = false;
      }
      else {
        this.invalidPfp = false;
        this.selectedPfp = true;
      } 
    }
    else {
      this.invalidPfp = false;
      this.invalidPfp = false;
      this.profilePicture = null;
    }
  }

}
