import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppointmentService } from '../services/appointment.service';
import { Appointment } from '../models/appointment';
import { UserService } from '../services/user.service';
import { NotificationService } from '../services/notification.service';

@Component({
  selector: 'app-appointments-doctor',
  templateUrl: './appointments-doctor.component.html',
  styleUrls: ['./appointments-doctor.component.css']
})
export class AppointmentsDoctorComponent implements OnInit {

  constructor(private router: Router, private appointmentService: AppointmentService, private userService: UserService, private notificationService: NotificationService) { }

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    if(this.loggedIn != "doctor"){
      this.router.navigate(['']);
      return;
    }
    this.userService.updateNavbar("doctor");
    this.username = sessionStorage.getItem("username");

    const date = {
      "doctor": this.username
    }
    this.appointmentService.getAppointmentsUpcomingForDoctor(date).subscribe((uaFromDb: Appointment[])=>{
      if(uaFromDb.length == 0) this.message = "Nema zakazanih pregleda"
      this.upcomingAppointments = uaFromDb;
      this.upcomingAppointments = this.appointmentService.sortAppointmentsByStartTime(this.upcomingAppointments);
    })
  }

  loggedIn: string;
  message: string;

  username: string;

  upcomingAppointments: Appointment[];

  cancel: boolean = false;
  cancel_date_and_time: Date;
  cancel_reason: string;
  patientUsername: string;

  startCancelProcess(date_and_time, patient){
    this.cancel_date_and_time = date_and_time
    this.cancel = true;
    this.patientUsername = patient;
  }

  cancelCancelProcess(){
    this.cancel = false;
    this.cancel_reason = "";
  }

  
  cancelAppointment(){
    const data = {
      "doctor": this.username,
      "start_date_and_time": this.cancel_date_and_time,
      "cancel_reason": this.cancel_reason
    }
    this.appointmentService.cancelAppointment(data).subscribe(respObj=>{
      if(respObj['message']=="ok"){
        const data2 = {
          "username": this.patientUsername,
          "title": "Otkazivanje pregleda",
          "content": this.cancel_reason
        }
        this.notificationService.createNotification(data2).subscribe(respObj=>{
          if(respObj['message']=="ok"){
            alert("Pregled uspesno otkazan")
            window.location.reload();
          }
          else{
            this.message = "Greska pri slanju notifikacije"
          }
        })
      }
      else{
        this.message = "Greska pri otkazivanju pregleda"
      }
    })

    

  }

  goToPatientRecord(patient){
    sessionStorage.setItem("patientForPatientRecord", patient);
    this.router.navigate(['patient_record']);
    this.message = "here"
  }

}
