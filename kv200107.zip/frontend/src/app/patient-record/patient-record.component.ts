import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { AppointmentService } from '../services/appointment.service';
import { Appointment } from '../models/appointment';

@Component({
  selector: 'app-patient-record',
  templateUrl: './patient-record.component.html',
  styleUrls: ['./patient-record.component.css']
})
export class PatientRecordComponent implements OnInit {

  constructor(private router: Router, private userService: UserService, private appointmentService: AppointmentService) { }

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    if(this.loggedIn != "doctor"){
      this.router.navigate(['']);
      return;
    }
    this.userService.updateNavbar("doctor");
    this.patientUsername = sessionStorage.getItem("patientForPatientRecord");

    this.userService.getPatientInfo(this.patientUsername).subscribe((patientFromDB: User)=>{
      if(patientFromDB == null || patientFromDB == undefined) this.message = "Greska pri dohvatanju kartona"
      this.patient = patientFromDB;
    })

    const data = {
      "patient": this.patientUsername
    }
    this.appointmentService.getPerformedAppointments(data).subscribe((fa: Appointment[])=>{
      if(fa.length == 0) this.faMessage == "Nema zavrsenih pregleda"
      else this.hasFinishedAppointments = true;
      
      this.finishedAppointments = fa;
      this.finishedAppointments = this.appointmentService.sortAppointmentsByStartTimeReverse(this.finishedAppointments);
    })

    const data2 = {
      "patient": this.patientUsername,
      "doctor": sessionStorage.getItem("username")
    }
    this.appointmentService.getCurrentAppointment(data2).subscribe((ca: Appointment[])=>{
      if(ca.length == 0) this.caMessage == "Trenutno se ne odrzava pregled"
      else this.hasCurrentAppointment = true;

      this.currentAppointment = ca;
    })

    const data3 = {
      "patient": this.patientUsername,
      "doctor": sessionStorage.getItem("username")
    }
    this.appointmentService.getPastAppointmentsWithoutReport(data3).subscribe((pa: Appointment[])=>{
      if(pa.length == 0) this.paMessage == "Nema zavrsenih pregleda bez izvestaja"
      else this.hasPastAppointmentsWithoutReport = true;

      this.pastAppointmentsWithoutReport = pa;
      this.pastAppointmentsWithoutReport = this.appointmentService.sortAppointmentsByStartTimeReverse(this.pastAppointmentsWithoutReport);
    })
  }

  loggedIn: string;
  message: string;

  patientUsername: string;
  patient: User;

  hasFinishedAppointments: boolean = false;
  finishedAppointments: Appointment[];
  faMessage: string;

  hasPastAppointmentsWithoutReport: boolean = false;
  pastAppointmentsWithoutReport: Appointment[];
  paMessage: string;

  hasCurrentAppointment: boolean = false;
  currentAppointment: Appointment[];
  caMessage: string;

  backToAppointments(){
    this.router.navigate(['appointments_doctor']);
  }

  prepareReport(appointment: Appointment){
    sessionStorage.setItem("patientForReport", appointment.patient)
    sessionStorage.setItem("doctorForReport", appointment.doctor)

    const data = {
      "date": appointment.start_date_and_time
    }
    sessionStorage.setItem("dateAndTimeOfAppointmentForReport", JSON.stringify(data));
  }

  submitReport(appointment: Appointment){
    this.prepareReport(appointment);

    this.router.navigate(['submit_report']);
  }

  lookAtReportForAppointment(appointment: Appointment){
    this.prepareReport(appointment);
    
    this.router.navigate(['view_report']);
  }

}
