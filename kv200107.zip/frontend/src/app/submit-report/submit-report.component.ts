import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';
import { ReportService } from '../services/report.service';
import { User } from '../models/user';

@Component({
  selector: 'app-submit-report',
  templateUrl: './submit-report.component.html',
  styleUrls: ['./submit-report.component.css']
})
export class SubmitReportComponent implements OnInit {

  constructor(private router: Router, private userService: UserService, private reportService: ReportService) { }

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    if(this.loggedIn != "doctor"){
      this.router.navigate(['']);
      return;
    }
    this.userService.updateNavbar("doctor");

    let patientUsername = sessionStorage.getItem("patientForReport")
    let doctorUsername = sessionStorage.getItem("doctorForReport");
    
    this.date_and_time_of_appointment = JSON.parse(sessionStorage.getItem("dateAndTimeOfAppointmentForReport"))['date'];

    this.userService.getPatientInfo(patientUsername).subscribe((userFromDB: User)=>{
      if(userFromDB == null) this.message = "Greska pri dohvatanju podataka o pacijentu"
      this.patient = userFromDB
    })

    this.userService.getDoctorInfo(doctorUsername).subscribe((userFromDB: User)=>{
      if(userFromDB == null) this.message = "Greska pri dohvatanju podataka o doktoru"
      this.doctor = userFromDB
    })
  }

  loggedIn: string;
  message: string;
  
  patient: User;
  doctor: User;
  date_and_time_of_appointment: Date;

  reason_for_appointment: string;
  diagnosis: string;
  recommended_therapy: string;
  next_appointment_recommended_date: Date;

  backToPatientRecord(){
    this.router.navigate(['patient_record']);
  }

  submitReport(){
    const data = {
      "patient": this.patient.username,
      "doctor": this.doctor.username,

      "date_and_time_of_appointment": this.date_and_time_of_appointment,
      "doctor_name": this.doctor.firstname + " " + this.doctor.lastname,
      "doctor_specialization": this.doctor.specialization,

      "reason_for_appointment": this.reason_for_appointment,
      "diagnosis": this.diagnosis,
      "recommended_therapy": this.recommended_therapy,
      "next_appointment_recommended_date": this.next_appointment_recommended_date
    }

    this.reportService.newReport(data).subscribe(respObj=>{
      if(respObj['message']=="ok"){
        alert("Izvestaj uspesno predat");
        this.router.navigate(['patient_record']);
      }
      else {
        this.message = "Greska pri predaji izvestaja"
      }
    })
  }

}
