import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { Specialization } from '../models/specialization';
import { Department } from '../models/department';
import { SpecializationService } from '../services/specialization.service';
import { DepartmentService } from '../services/department.service';
import { JsonPipe } from '@angular/common';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {

  constructor(private router: Router, private userService: UserService, private specializationService: SpecializationService, private departmentService: DepartmentService) { }

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    if(this.loggedIn == "patient") {
      this.patient = true;
      this.admin = false;
      this.username = sessionStorage.getItem("username");
      this.firstname = sessionStorage.getItem("firstname");
      this.lastname = sessionStorage.getItem("lastname");
      this.address = sessionStorage.getItem("address");
      this.email = sessionStorage.getItem("email");
      this.originalEmail = this.email;
      this.phone_number = sessionStorage.getItem("phone_number");
    }
    else if(this.loggedIn == "doctor"){
      this.getSpecializationsAndDepartments();
      this.patient = false;
      this.admin = false;
      this.username = sessionStorage.getItem("username");
      this.firstname = sessionStorage.getItem("firstname");
      this.lastname = sessionStorage.getItem("lastname");
      this.address = sessionStorage.getItem("address");
      this.email = sessionStorage.getItem("email");
      this.originalEmail = this.email;
      this.phone_number = sessionStorage.getItem("phone_number");
      this.license_number = sessionStorage.getItem("license_number");
      this.specialization = sessionStorage.getItem("specialization");
      this.originalSpecialization = this.specialization;
      this.department = sessionStorage.getItem("department");
    }
    else if(this.loggedIn == "admin"){
      this.admin = true;
      this.getSpecializationsAndDepartments();
      let userType = sessionStorage.getItem("typeForAdmin");
      if(userType == "2"){
        this.patient = true;
        this.userService.getPatientInfo(sessionStorage.getItem("usernameForAdmin")).subscribe((UserFromDB: User)=>{
          this.username = UserFromDB.username;
          this.firstname = UserFromDB.firstname;
          this.lastname = UserFromDB.lastname;
          this.address = UserFromDB.address;
          this.email = UserFromDB.email;
          this.originalEmail = this.email;
          this.phone_number = UserFromDB.phone_number;
          this.license_number = UserFromDB.license_number;
          this.specialization = UserFromDB.specialization;
          this.originalSpecialization = this.specialization;
          this.department = UserFromDB.department;
        })
      }
      else if (userType == "1"){
        this.userService.getDoctorInfo(sessionStorage.getItem("usernameForAdmin")).subscribe((UserFromDB: User)=>{
          this.patient = false;
          
          this.username = UserFromDB.username;
          this.firstname = UserFromDB.firstname;
          this.lastname = UserFromDB.lastname;
          this.address = UserFromDB.address;
          this.email = UserFromDB.email;
          this.originalEmail = this.email;
          this.phone_number = UserFromDB.phone_number;
          this.license_number = UserFromDB.license_number;
          this.specialization = UserFromDB.specialization;
          this.originalSpecialization = this.specialization;
          this.department = UserFromDB.department;
        })
      }
      
    }
    else{
      this.router.navigate(['']);
      return;
    }
    //this.message = this.patient ? "pacijent" : "doktor"
  }

  getSpecializationsAndDepartments(){
    this.specializationService.getAllSpecializations().subscribe((SpecializationsFromDB: Specialization[]) => {
      if(SpecializationsFromDB != null){
        this.specializations = SpecializationsFromDB;
      }
      else{
        this.message = "Greska pri dohvatanju specijalizacija"
      }
    });

    this.departmentService.getAllDepartments().subscribe((DepartmentsFromDB: Department[]) => {
      if(DepartmentsFromDB != null){
        this.departments = DepartmentsFromDB;
      }
      else{
        this.message = "Greska pri dohvatanju ogranaka"
      }
    });
  }


  specializations: Specialization[];
  departments: Department[];

  admin: boolean;
  patient: boolean;
  message: string;
  loggedIn: string;
  username: string;

  firstname: string;
  lastname: string;
  address: string;
  email: string;
  phone_number: string;

  license_number: string;
  specialization: string;
  department: string;

  originalEmail: string;
  originalSpecialization: string;

  backToProfile(){
    this.router.navigate(['user']);
  }

  edit(){
    if(this.patient) this.editPatientInfo()
    else this.editDoctorInfo();
  }

  editPatientInfo(){
    const data = {
      "username": this.username,
      "firstname": this.firstname,
      "lastname": this.lastname,
      "address": this.address,
      "phone_number": this.phone_number,
      "email": this.email,
      "emailEdit": this.email != this.originalEmail
    }
    this.userService.editPatientInfo(data).subscribe(respObj=>{
      if(respObj['message']=="email taken"){
        this.message = "Email adresa nije dostupna"
      }
      else if(respObj['message']=="ok"){
        this.message = ""
        alert("Uspesno promenjeni licni podaci")
        this.userService.getPatientInfo(this.username).subscribe((userFromDB: User)=>{
          if(userFromDB!=null){
            sessionStorage.setItem("firstname", userFromDB.firstname);
            sessionStorage.setItem("lastname", userFromDB.lastname);
            sessionStorage.setItem("address", userFromDB.address);
            sessionStorage.setItem("phone_number", userFromDB.phone_number);
            sessionStorage.setItem("email", userFromDB.email);
            this.userService.updateNavbar(this.loggedIn);
            this.router.navigate(['user']);
          }
          else{
            this.message="Greska"
          }
        })
        
      }
      else{
        this.message="Greska pri promeni licnih podataka"
      }
    })
  }

  editDoctorInfo(){
    const data = {
      "username": this.username,
      "firstname": this.firstname,
      "lastname": this.lastname,
      "address": this.address,
      "phone_number": this.phone_number,
      "email": this.email,
      "emailEdit": this.email != this.originalEmail,
      "license_number": this.license_number,
      "specialization": this.specialization,
      "specializationEdit": this.specialization != this.originalSpecialization,
      "department": this.department
    }
    this.userService.editDoctorInfo(data).subscribe(respObj=>{
      if(respObj['message']=="email taken"){
        this.message = "Email adresa nije dostupna"
      }
      else if(respObj['message']=="ok"){
        this.message = ""
        alert("Uspesno promenjeni licni podaci")
        this.userService.getDoctorInfo(this.username).subscribe((userFromDB: User)=>{
          if(userFromDB!=null){
            sessionStorage.setItem("firstname", userFromDB.firstname);
            sessionStorage.setItem("lastname", userFromDB.lastname);
            sessionStorage.setItem("address", userFromDB.address);
            sessionStorage.setItem("phone_number", userFromDB.phone_number);
            sessionStorage.setItem("email", userFromDB.email);
            sessionStorage.setItem("license_number", userFromDB.license_number);
            sessionStorage.setItem("specialization", userFromDB.specialization);
            sessionStorage.setItem("department", userFromDB.department);
            this.userService.updateNavbar(this.loggedIn);
            this.router.navigate(['user']);
          }
          else{
            this.message="Greska"
          }
        })
        
      }
      else{
        this.message="Greska pri promeni licnih podataka"
      }
    })
  }

  updateSpecialization(e){
    this.specialization = e.target.value;
    this.specialization = this.specialization.substring(3);
  }

  updateDepartment(e){
    this.department = e.target.value;
    this.department = this.department.substring(3);
  }

}
