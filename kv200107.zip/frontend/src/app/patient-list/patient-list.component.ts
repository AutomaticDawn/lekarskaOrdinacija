import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-patient-list',
  templateUrl: './patient-list.component.html',
  styleUrls: ['./patient-list.component.css']
})
export class PatientListComponent implements OnInit {

  constructor(private router: Router, private userService: UserService) { }

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    if(this.loggedIn != "admin") {
      this.router.navigate(['']);
      return;
    }

    this.userService.getAllPatients().subscribe((patientsFromDB: User[])=>{
      if(patientsFromDB.length == 0) this.message = "Nema pacijenata"
      this.patients = patientsFromDB;
    })
  }

  loggedIn: string;
  message: string;

  patients: User[]

  viewProfile(username){
    sessionStorage.setItem("usernameForAdmin", username);
    sessionStorage.setItem("typeForAdmin", "2");
    this.router.navigate(['user']);
  }

  deleteUser(username){
    this.message = ""
    const data = {
      "username": username
    }
    this.userService.deleteUser(data).subscribe(respObj=>{
      if(respObj['message']=="ok"){
        alert("Korisnik uspesno izbrisan")
        this.ngOnInit();
      }
      else{
        this.message = "Greska pri brisanju korisnika"
      }
    })
  }

}
