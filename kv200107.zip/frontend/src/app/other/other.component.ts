import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-other',
  templateUrl: './other.component.html',
  styleUrls: ['./other.component.css']
})
export class OtherComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    if(this.loggedIn != "doctor"){
      this.router.navigate(['']);
    }
  }

  loggedIn: string;
  message: string;

  goToRequestNewAppointmentType(){
    this.router.navigate(['request_new_appointment_type']);
  }

  goToSetFreeDays(){
    this.router.navigate(['set_free_days']);
  }

}
