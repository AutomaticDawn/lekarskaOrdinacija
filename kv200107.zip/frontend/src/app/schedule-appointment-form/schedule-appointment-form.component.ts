import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';
import { Time } from '@angular/common';
import * as moment from 'moment';
import { AppointmentService } from '../services/appointment.service';
import { User } from '../models/user';

@Component({
  selector: 'app-schedule-appointment-form',
  templateUrl: './schedule-appointment-form.component.html',
  styleUrls: ['./schedule-appointment-form.component.css']
})
export class ScheduleAppointmentFormComponent implements OnInit {

  constructor(private router: Router, private userService: UserService, private appointmentService: AppointmentService) { }

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    if(this.loggedIn != "patient"){
      this.router.navigate(['']);
      return;
    }

    this.patientUsername = sessionStorage.getItem("patientUsername");
    this.userService.getPatientInfo(this.patientUsername).subscribe((patient: User)=>{
      if(patient == null) this.message = "Greska pri dohvatanju pacijenta"
      this.patient = patient;
    })

    this.doctorUsername = sessionStorage.getItem("doctorUsername");
    this.userService.getDoctorInfo(this.doctorUsername).subscribe((doctor: User)=>{
      if(doctor == null) this.message = "Greska pri dohvatanju doktora"
      this.doctor = doctor;
    })

    this.appointmentTypeName = sessionStorage.getItem("appointmentTypeName");
    this.appointmentTypeLength = sessionStorage.getItem("appointmentTypeLength");
    this.now = new Date();
    //this.message = this.now.toLocaleString();
  }

  loggedIn: string;
  message: string;

  patientUsername: string;
  patient: User;

  doctorUsername: string;
  doctor: User;

  appointmentTypeName: string;
  appointmentTypeLength: string;

  //today: Date;
  startDateTime: Date;
  endDateTime: Date;
  now: Date;

  goBackToDoctorProfile(){
    this.router.navigate(['user']);
  }

  scheduleAppointment(){
    if(moment(this.startDateTime).isBefore(this.now)){
      this.message = "Zakazite termin u buducnosti"
      return;
    }

    this.startDateTime = moment(this.startDateTime).add(0, "m").toDate();
    this.endDateTime = moment(this.startDateTime).add(this.appointmentTypeLength.valueOf(), "m").toDate();

    //this.startDateTime = moment(this.startDateTime).add(2, "h").toDate();
    //this.endDateTime = moment(this.endDateTime).add(2, "h").toDate();

    //this.message = this.startDateTime.toLocaleString() + " - " + this.endDateTime.toLocaleString();

    const data = {
      "patient": this.patient.username,
      "patient_firstname": this.patient.firstname,
      "patient_lastname": this.patient.lastname,
      "doctor": this.doctor.username,
      "doctor_firstname": this.doctor.firstname,
      "doctor_lastname": this.doctor.lastname,
      "appointment_type": this.appointmentTypeName,
      "department": this.doctor.department,
      "start_date_and_time": this.startDateTime,
      "end_date_and_time": this.endDateTime
    }
    this.appointmentService.newAppointment(data).subscribe(respObj=>{
      if(respObj['message']=="ok"){
        this.message = "Termin zakazan"
        alert("Termin uspesno zakazan");
        this.router.navigate(['']);
      }
      else if(respObj['message']=="not available"){
        this.message = "Predlozeni termin nije dostupan"
      }
      else{
        this.message = "Greska pri zakazivanju termina"
      }
    })
  }
}
