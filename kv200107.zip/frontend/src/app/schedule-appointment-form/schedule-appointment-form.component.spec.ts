import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ScheduleAppointmentFormComponent } from './schedule-appointment-form.component';

describe('ScheduleAppointmentFormComponent', () => {
  let component: ScheduleAppointmentFormComponent;
  let fixture: ComponentFixture<ScheduleAppointmentFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ScheduleAppointmentFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ScheduleAppointmentFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
