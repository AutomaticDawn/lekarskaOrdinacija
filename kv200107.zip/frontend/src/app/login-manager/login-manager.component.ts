import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { BnNgIdleService } from 'bn-ng-idle';

@Component({
  selector: 'app-login-manager',
  templateUrl: './login-manager.component.html',
  styleUrls: ['./login-manager.component.css']
})
export class LoginManagerComponent implements OnInit {

  constructor(private userService: UserService, private router: Router, private bnNgIdleService: BnNgIdleService) { }

  ngOnInit(): void {
  }

  username: string;
  password: string;
  
  message: string = "";

  login(){
    this.userService.login(this.username, this.password).subscribe((userFromDB: User)=>{
      if(userFromDB!=null){
        this.message = "";
        if(userFromDB.type==0){
          sessionStorage.setItem("loggedIn", "admin");
          sessionStorage.setItem("username", userFromDB.username);
          this.userService.updateNavbar("admin")

          this.bnNgIdleService.startWatching(900).subscribe((isTimedOut: boolean) => {
            if(isTimedOut){
              sessionStorage.clear();
              this.userService.updateNavbar("false");
              this.userService.updateCanSeeDoctorProfilesOnHome("false");
              this.router.navigate(['login_manager']);
              this.bnNgIdleService.stopTimer();
              alert("Izlogovani ste zbog neaktivnosti")
            }
          })

          this.router.navigate(['admin']);
        }
        else{
          this.message="Neispravni podaci";
        }
      }
      else{
        this.message="Neispravni podaci";
      }
    })
  }
}
