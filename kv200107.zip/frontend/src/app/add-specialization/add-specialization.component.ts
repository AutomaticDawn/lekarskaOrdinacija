import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SpecializationService } from '../services/specialization.service';

@Component({
  selector: 'app-add-specialization',
  templateUrl: './add-specialization.component.html',
  styleUrls: ['./add-specialization.component.css']
})
export class AddSpecializationComponent implements OnInit {

  constructor(private router: Router, private specializationService: SpecializationService) { }

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    if(this.loggedIn != "admin") {
      this.router.navigate(['']);
      return;
    }
  }

  loggedIn: string;
  message: string;

  name: string;

  addSpecialization(){
    const data = {
      "name": this.name
    }
    this.specializationService.addSpecialization(data).subscribe(respObj=>{
      if(respObj['message']=="ok"){
        this.message = ""
        alert("Nova specijalizacija uspesno dodata");
        this.router.navigate(['']);
      }
      else{
        this.message = "Greska pri dodavanju nove specijalizacije"
      }
    })
  }
}
