import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppointmentTypeService } from '../services/appointment-type.service';

@Component({
  selector: 'app-edit-appointment-type',
  templateUrl: './edit-appointment-type.component.html',
  styleUrls: ['./edit-appointment-type.component.css']
})
export class EditAppointmentTypeComponent implements OnInit {

  constructor(private router: Router, private appointmentTypeService: AppointmentTypeService) { }

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    if(this.loggedIn != "admin"){
      this.router.navigate(['']);
      return;
    }

    this.name = sessionStorage.getItem("atNameForEdit");
    this.length = sessionStorage.getItem("atLengthForEdit");
    this.price = sessionStorage.getItem("atPriceForEdit");
  }

  loggedIn: string;
  message: string;

  name: string;
  length: string;
  price: string;

  editAppointmentType(){
    const data = {
      "name": this.name,
      "length": this.length,
      "price": this.price
    }
    this.appointmentTypeService.editAppointmentType(data).subscribe(respObj=>{
      if(respObj['message']=="ok"){
        this.message = ""
        alert("Uspesno azurirana vrsta pregleda")
        this.router.navigate(['appointment_type_list']);
      }
      else{
        this.message = "Greska pri azuriranju vrste pregleda"
      }
    })
  }

}
