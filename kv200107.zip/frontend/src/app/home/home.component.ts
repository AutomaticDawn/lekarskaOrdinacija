import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { User } from '../models/user';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private userService: UserService) { }

  loggedIn: string;
  message: string = "poruka";

  searchInput: string;

  doctors: User[];

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    this.userService.updateNavbar(this.loggedIn);

    this.userService.getAllDoctors().subscribe((data: User[])=>{
      this.doctors = data;
    });
  }
}
