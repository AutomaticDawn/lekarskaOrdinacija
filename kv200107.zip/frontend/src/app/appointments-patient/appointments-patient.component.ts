import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppointmentService } from '../services/appointment.service';
import { Appointment } from '../models/appointment';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-appointments-patient',
  templateUrl: './appointments-patient.component.html',
  styleUrls: ['./appointments-patient.component.css']
})
export class AppointmentsPatientComponent implements OnInit {

  constructor(private router: Router, private appointmentService: AppointmentService, private userService: UserService) { }

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    if(this.loggedIn != "patient"){
      this.router.navigate(['']);
      return;
    }
    this.username = sessionStorage.getItem("username");

    this.userService.updateNavbar("patient");

    const data = {
      "patient": this.username
    }
    this.appointmentService.getAppointmentsUpcomingForPatient(data).subscribe((ua: Appointment[])=>{
      if(ua.length == 0) this.uaMessage == "Nema zakazanih pregleda"
      this.upcomingAppointments = ua;
      
      //this.message = JSON.stringify(this.upcomingAppointments);
      this.upcomingAppointments = this.appointmentService.sortAppointmentsByStartTime(this.upcomingAppointments);
    })

    this.appointmentService.getAppointmentsFinishedForPatient(data).subscribe((fa: Appointment[])=>{
      if(fa.length == 0) this.faMessage == "Nema zavrsenih pregleda"
      this.finishedAppointments = fa;

      this.finishedAppointments = this.appointmentService.sortAppointmentsByStartTimeReverse(this.finishedAppointments);
    })
  }

  loggedIn: string;
  message: string;

  username: string;

  upcomingAppointments: Appointment[];
  finishedAppointments: Appointment[];
  uaMessage: string;
  faMessage: string;

  cancelAppointment(doctor, start_date_and_time){
    const data = {
      "doctor": doctor,
      "start_date_and_time": start_date_and_time,
      "cancel_reason": "Pacijent"
    }
    this.appointmentService.cancelAppointment(data).subscribe(respObj=>{
      if(respObj['message']=="ok"){
        alert("Pregled uspesno otkazan")
        window.location.reload();
      }
      else{
        this.message = "Greska pri otkazivanju pregleda"
      }
    })
  }

  viewReport(appointment: Appointment){
    sessionStorage.setItem("patientForReport", appointment.patient)
    sessionStorage.setItem("doctorForReport", appointment.doctor)

    const data = {
      "date": appointment.start_date_and_time
    }
    sessionStorage.setItem("dateAndTimeOfAppointmentForReport", JSON.stringify(data));
    
    this.router.navigate(['view_report']);
  }
}
