import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NotificationService } from '../services/notification.service';
import { Notification } from '../models/notification';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit {

  constructor(private router: Router, private notificationService: NotificationService) { }

  ngOnInit(): void {
    this.loggedIn = sessionStorage.getItem("loggedIn");
    if(this.loggedIn != "patient"){
      this.router.navigate(['']);
      return;
    }
    this.username = sessionStorage.getItem("username")

    const data = {
      "username": this.username
    }

    this.notificationService.getAllUnviewedNotifiactionsForUser(data).subscribe((uvn: Notification[])=>{
      if(uvn.length == 0){
        this.uvnMessage = "Nema novih notifikacija"
        this.hasUvn = false;
      }
      this.unviewedNotifications = uvn;
      this.notificationService.getAllViewedNotifiactionsForUser(data).subscribe((vn: Notification[])=>{
        if(vn.length == 0){
          this.vnMessage = "Nema prethodnih notifikacija"
          this.hasVn = false;
        }
        this.viewedNotifications = vn;
        this.notificationService.viewAllNotifications(data).subscribe(respObj=>{
          if(respObj['message'] == "ok"){
            this.message = "works"
          }
          else {
            this.message = "Greska pri potvrdi vidjenja notifikacija"
          }
        })
      })
    })
  }

  loggedIn: string;
  message: string;

  username: string;

  unviewedNotifications: Notification[]
  viewedNotifications: Notification[]
  uvnMessage: string = "";
  vnMessage: string = "";
  hasUvn: boolean = true;
  hasVn: boolean = true;
}
