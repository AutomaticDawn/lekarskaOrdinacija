import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {

  constructor(private http: HttpClient) { }

  uri = 'http://localhost:4000'

  getAllUnviewedNotifiactionsForUser(data){
    return this.http.post(this.uri + '/notifications/getAllUnviewedNotifiactionsForUser', data);
  }

  getAllViewedNotifiactionsForUser(data){
    return this.http.post(this.uri + '/notifications/getAllViewedNotifiactionsForUser', data);
  }

  createNotification(data){
    return this.http.post(this.uri + '/notifications/createNotification', data);
  }

  viewAllNotifications(data){
    return this.http.post(this.uri + '/notifications/viewAllNotifications', data);
  }
}
