import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Appointment } from '../models/appointment';

@Injectable({
  providedIn: 'root'
})
export class AppointmentService {

  constructor(private http: HttpClient) { }

  sortAppointmentsByStartTime(appointments: Appointment[]): Appointment[]{
    return appointments.sort((appointment1, appointment2)=>{
      return appointment1.start_date_and_time.toLocaleString().localeCompare(appointment2.start_date_and_time.toLocaleString());
    });
  }

  sortAppointmentsByStartTimeReverse(appointments: Appointment[]): Appointment[]{
    return appointments.sort((appointment1, appointment2)=>{
      return appointment2.start_date_and_time.toLocaleString().localeCompare(appointment1.start_date_and_time.toLocaleString());
    });
  }

  uri = 'http://localhost:4000'

  newAppointment(data){
    return this.http.post(this.uri + '/appointments/newAppointment', data);
  }

  getAppointmentsUpcomingForPatient(data){
    return this.http.post(this.uri + '/appointments/getAppointmentsUpcomingForPatient', data);
  }

  getAppointmentsFinishedForPatient(data){
    return this.http.post(this.uri + '/appointments/getAppointmentsFinishedForPatient', data);
  }

  getAppointmentsUpcomingForDoctor(data){
    return this.http.post(this.uri + '/appointments/getAppointmentsUpcomingForDoctor', data);
  }
  
  getAppointmentsFinishedForDoctor(data){
    return this.http.post(this.uri + '/appointments/getAppointmentsFinishedForDoctor', data);
  }

  cancelAppointment(data){
    return this.http.post(this.uri + '/appointments/cancelAppointment', data);
  }

  //za patient record

  getPerformedAppointments(data){
    return this.http.post(this.uri + '/appointments/getPerformedAppointments', data);
  }

  getCurrentAppointment(data){
    return this.http.post(this.uri + '/appointments/getCurrentAppointment', data);
  }

  getPastAppointmentsWithoutReport(data){
    return this.http.post(this.uri + '/appointments/getPastAppointmentsWithoutReport', data);
  }
}
