import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AppointmentTypeService {

  constructor(private http: HttpClient) { }

  uri = 'http://localhost:4000'

  addNewAppointmentTypeUnapproved(data){
    return this.http.post(this.uri + "/appointmentTypes/addNewAppointmentTypeUnapproved", data)
  }

  addNewAppointmentTypeApproved(data){
    return this.http.post(this.uri + "/appointmentTypes/addNewAppointmentTypeApproved", data);
  }

  approveNewAppointmentType(data){
    return this.http.post(this.uri + "/appointmentTypes/approveNewAppointmentType", data);
  }

  denyNewAppointmentType(data){
    return this.http.post(this.uri + "/appointmentTypes/denyNewAppointmentType", data);
  }

  editAppointmentType(data){
    return this.http.post(this.uri + "/appointmentTypes/editAppointmentType", data);
  }

  deleteAppointmentType(data){
    return this.http.post(this.uri + "/appointmentTypes/deleteAppointmentType", data);
  }

  getAllAppointmentTypesForSpecialization(specialization){
    return this.http.get(this.uri + `/appointmentTypes/getAllAppointmentTypesForSpecialization?specialization=${specialization}`)
  }

  getAllUnapprovedAppointmentTypes(){
    return this.http.get(this.uri + `/appointmentTypes/getAllUnapprovedAppointmentTypes`)
  }

  getAppointmentTypes(data){
    return this.http.post(this.uri + `/appointmentTypes/getAppointmentTypes`, data);
  }
}
