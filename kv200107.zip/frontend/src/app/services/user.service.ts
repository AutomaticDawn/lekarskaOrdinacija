import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  defaultPfp: File;

  constructor(private http: HttpClient) {}

  private loggedInSource = new BehaviorSubject('false');
  currentLoggedIn = this.loggedInSource.asObservable();
  updateNavbar(message: string) {
    this.loggedInSource.next(message)
  }

  private canSeeDoctorProfilesOnHome = new BehaviorSubject('false');
  currentCanSeeDoctorProfilesOnHome = this.canSeeDoctorProfilesOnHome.asObservable();
  updateCanSeeDoctorProfilesOnHome(message: string) {
    this.canSeeDoctorProfilesOnHome.next(message)
  }

  sortUsersByFirstname(users: User[]): User[]{
    return users.sort((user1, user2)=>{
      return user1.firstname.localeCompare(user2.firstname);
    });
  }

  sortUsersByFirstnameReverse(users: User[]): User[]{
    return users.sort((user1, user2)=>{
      return user2.firstname.localeCompare(user1.firstname);
    });
  }

  sortUsersByLastname(users: User[]): User[]{
    return users.sort((user1, user2)=>{
      return user1.lastname.localeCompare(user2.lastname);
    });
  }

  sortUsersByLastnameReverse(users: User[]): User[]{
    return users.sort((user1, user2)=>{
      return user2.lastname.localeCompare(user1.lastname);
    });
  }

  sortUsersBySpecialization(users: User[]): User[]{
    return users.sort((user1, user2)=>{
      return user1.specialization.localeCompare(user2.specialization);
    });
  }

  sortUsersBySpecializationReverse(users: User[]): User[]{
    return users.sort((user1, user2)=>{
      return user2.specialization.localeCompare(user1.specialization);
    });
  }

  sortUsersByDepartment(users: User[]): User[]{
    return users.sort((user1, user2)=>{
      return user1.department.localeCompare(user2.department);
    });
  }

  sortUsersByDepartmentReverse(users: User[]): User[]{
    return users.sort((user1, user2)=>{
      return user2.department.localeCompare(user1.department);
    });
  }

  uri = 'http://localhost:4000'

  login(usernameFromForm, passwordFromForm){
    const data = {
      username: usernameFromForm,
      password: passwordFromForm
    }

    return this.http.post(this.uri + '/users/login', data);
  }

  registerPatient(data){
    return this.http.post(this.uri + '/users/registerPatient', data);
  }

  registerDoctor(data){
    return this.http.post(this.uri + '/users/registerDoctor', data);
  }

  validateUsernameAndEmail(usernameFromForm, emailFromForm){
    const data = {
      username: usernameFromForm,
      email: emailFromForm
    }

    return this.http.post(this.uri + '/users/validateUsernameAndEmail', data);
  }

  approveNewPatient(data){
    return this.http.post(this.uri + '/users/approveNewPatient', data);
  }

  denyNewPatient(data){
    return this.http.post(this.uri + '/users/denyNewPatient', data);
  }

  changePassword(data){
    return this.http.post(this.uri + '/users/changePassword', data);
  }

  getPatientInfo(username){
    return this.http.get(this.uri + `/users/getPatientInfo?username=${username}`);
  }

  editPatientInfo(data){
    return this.http.post(this.uri + '/users/editPatientInfo', data);
  }

  getDoctorInfo(username){
    return this.http.get(this.uri + `/users/getDoctorInfo?username=${username}`);
  }

  searchDoctors(data){
    return this.http.post(this.uri + `/users/searchDoctors`, data);
  }

  editDoctorInfo(data){
    return this.http.post(this.uri + '/users/editDoctorInfo', data);
  }

  editPfp(data){
    return this.http.post(this.uri + '/users/editPfp', data);
  }

  getAllPatients(){
    return this.http.get(this.uri + '/users/getAllPatients');
  }

  getAllUnapprovedPatients(){
    return this.http.get(this.uri + '/users/getAllUnapprovedPatients');
  }

  getAllDoctors(){
    return this.http.get(this.uri + '/users/getAllDoctors');
  }

  deleteUser(data){
    return this.http.post(this.uri + '/users/deleteUser', data);
  }

  updateAppointmentTypesForDoctor(data){
    return this.http.post(this.uri + '/users/updateAppointmentTypesForDoctor', data);
  }
}
