import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ReportService {

  constructor(private http: HttpClient) { }

  uri = 'http://localhost:4000'

  newReport(data){
    return this.http.post(this.uri + '/reports/newReport', data);
  }

  getReport(data){
    return this.http.post(this.uri + '/reports/getReport', data);
  }

  getAllReportsForPatient(data){
    return this.http.post(this.uri + '/reports/getAllReportsForPatient', data);
  }
}
