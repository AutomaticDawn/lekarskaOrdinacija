import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register-patient',
  templateUrl: './register-patient.component.html',
  styleUrls: ['./register-patient.component.css']
})
export class RegisterPatientComponent implements OnInit {

  constructor(private userService: UserService, private router: Router) { }

  message: string = "";

  username: string;
  password: string;
  confirmPassword: string;
  firstname: string;
  lastname: string;
  address: string;
  phone_number: string;
  email: string;

  profilePicture: File;
  invalidPfp: boolean = false;

  ngOnInit(): void {
  }

  registerPatient(){
    this.message = "";

    let canRegister = true;
    this.userService.validateUsernameAndEmail(this.username, this.email).subscribe(respObj=>{
      if(respObj['usernameTaken']){
        this.message += " Korisnicko ime je vec uzeto."
        canRegister = false;
      }
      if(respObj['emailTaken']){
        this.message += " Email adresa je vec uzeta."
        canRegister = false;
      }

      let form = new FormData();
      form.append("username", this.username);
      form.append("password", this.password);
      form.append("firstname", this.firstname);
      form.append("lastname", this.lastname);
      form.append("address", this.address);
      form.append("phone_number", this.phone_number);
      form.append("email", this.email);
      form.append("pfp", this.profilePicture);

      if(canRegister){
        this.userService.registerPatient(form).subscribe(respObj=>{
          if(respObj['message']=='ok') {
            this.router.navigate(['register_success']);
          }
          else{
            this.message = 'Registracija neuspešna';
          }
        });
      }
    })
  }

  async isPfpValid(event:any) {
    if(event.target.value) {
      this.profilePicture = <File>event.target.files[0]
      let profilePicture = new Image();
      profilePicture.src = URL.createObjectURL(this.profilePicture);
      await profilePicture.decode();
      if(profilePicture.naturalWidth < 100 || profilePicture.naturalWidth > 300 || profilePicture.naturalHeight < 100 || profilePicture.naturalHeight > 300) this.invalidPfp = true;
      else this.invalidPfp = false;
    }
    else {
      this.invalidPfp = false;
      this.profilePicture = null;
    }
  }
}
