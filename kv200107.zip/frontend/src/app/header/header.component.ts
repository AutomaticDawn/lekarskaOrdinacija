import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';
import { NotificationService } from '../services/notification.service';
import { Notification } from '../models/notification';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private router: Router, private userService: UserService, private notificationService: NotificationService) {
    this.userService.currentLoggedIn.subscribe(message => {
      if(message == "patient"){
        this.loggedIn = true;
        this.patient = true;
        this.doctor = false;
        this.admin = false;
        const data = {
          "username": sessionStorage.getItem("username")
        }
        this.notificationService.getAllUnviewedNotifiactionsForUser(data).subscribe((uvn: Notification[])=>{
          this.unviewedNotificationCount = uvn.length;
        })
      }
      else if(message == "doctor"){
        this.loggedIn = true;
        this.patient = false;
        this.doctor = true;
        this.admin = false;
      }
      else if(message == "admin"){
        this.loggedIn = true;
        this.patient = false;
        this.doctor = false;
        this.admin = true;
      }
      else{
        this.loggedIn = false;
        this.patient = false;
        this.doctor = false;
        this.admin = false;
      }
    });
  }

  ngOnInit(): void {
  }

  loggedIn: boolean = false;
  patient: boolean = false;
  doctor: boolean = false;
  admin: boolean = false;

  unviewedNotificationCount: number;

  //all
  logout(){
    sessionStorage.clear();
    this.loggedIn = false;
    this.patient = false;
    this.doctor = false;
    this.admin = false;
    this.router.navigate(['']);
    this.userService.updateCanSeeDoctorProfilesOnHome("false");
    alert("Korisnik uspešno izlogovan")
  }

  home(){
    let loggedIn = sessionStorage.getItem("loggedIn");
    if(loggedIn == "admin") {
      this.userService.updateNavbar("admin");
      this.router.navigate(['admin']);
    }
    else if(loggedIn == "doctor"){
      this.userService.updateNavbar("doctor");
      this.router.navigate(['']);
    }
    else if(loggedIn == "patient"){
      this.userService.updateNavbar("patient");
      this.router.navigate(['']);
    }
    else {
      this.userService.updateNavbar("false");
      this.router.navigate(['']);
    }
  }


  //logged out
  login(){
    this.router.navigate(['login']);
  }

  registerPatient(){
    this.router.navigate(['register']);
  }


  //patient
  patientInfo(){
    sessionStorage.setItem("usernameForPatient", "false");
    this.router.navigate(['user']);
  }

  doctorsInfo(){
    this.router.navigate(['search_doctors']);
  }

  appointments(){
    this.router.navigate(['appointments_patient']);
  }

  notifications(){
    this.router.navigate(['notifications']);
  }

  //doctor

  doctorInfo(){
    this.router.navigate(['user']);
  }

  appointmentsDoctor(){
    this.router.navigate(['appointments_doctor']);
  }

  other(){
    this.router.navigate(['other']);
  }

  //admin
  newPatientRequests(){
    this.router.navigate(['patient_requests']);
  }

  allPatients(){
    this.router.navigate(['patient_list']);
  }

  registerDoctor(){
    this.router.navigate(['register_doctor']);
  }

  allDoctors(){
    this.router.navigate(['doctor_list']);
  }

  registerSpecialization(){
    this.router.navigate(['add_specialization']);
  }

  addNewAppointmentType(){
    this.router.navigate(['request_new_appointment_type']);
  }

  newAppointmentTypeRequests(){
    this.router.navigate(['appointment_type_requests']);
  }

  allAppointmentTypes(){
    this.router.navigate(['appointment_type_list']);
  }

  
  
}
