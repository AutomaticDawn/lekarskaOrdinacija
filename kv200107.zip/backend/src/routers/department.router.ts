import express from "express";
import { DepartmentController } from "../controllers/department.controller";

const departmentRouter = express.Router();

departmentRouter.route('/getAllDepartments').get(
    (req, res) => new DepartmentController().getAllDepartments(req, res)
);

export default departmentRouter;