import express from "express";
import { AppointmentController } from "../controllers/appointment.controller";

const appointmentRouter = express.Router();

appointmentRouter.route('/newAppointment').post(
    (req, res) => new AppointmentController().newAppointment(req, res)
);

appointmentRouter.route('/getAppointmentsUpcomingForPatient').post(
    (req, res) => new AppointmentController().getAppointmentsUpcomingForPatient(req, res)
);

appointmentRouter.route('/getAppointmentsFinishedForPatient').post(
    (req, res) => new AppointmentController().getAppointmentsFinishedForPatient(req, res)
);

appointmentRouter.route('/getAppointmentsUpcomingForDoctor').post(
    (req, res) => new AppointmentController().getAppointmentsUpcomingForDoctor(req, res)
);

appointmentRouter.route('/getAppointmentsFinishedForDoctor').post(
    (req, res) => new AppointmentController().getAppointmentsFinishedForDoctor(req, res)
);

appointmentRouter.route('/cancelAppointment').post(
    (req, res) => new AppointmentController().cancelAppointment(req, res)
);

//za patient record

appointmentRouter.route('/getPerformedAppointments').post(
    (req, res) => new AppointmentController().getPerformedAppointments(req, res)
);

appointmentRouter.route('/getCurrentAppointment').post(
    (req, res) => new AppointmentController().getCurrentAppointment(req, res)
);

appointmentRouter.route('/getPastAppointmentsWithoutReport').post(
    (req, res) => new AppointmentController().getPastAppointmentsWithoutReport(req, res)
);

export default appointmentRouter;