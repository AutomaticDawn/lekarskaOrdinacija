import express from "express";
import { NotifiactionController } from "../controllers/notification.controller";

const notificationRouter = express.Router();

notificationRouter.route('/getAllUnviewedNotifiactionsForUser').post(
    (req, res) => new NotifiactionController().getAllUnviewedNotifiactionsForUser(req, res)
);

notificationRouter.route('/getAllViewedNotifiactionsForUser').post(
    (req, res) => new NotifiactionController().getAllViewedNotifiactionsForUser(req, res)
);

notificationRouter.route('/createNotification').post(
    (req, res) => new NotifiactionController().createNotification(req, res)
);

notificationRouter.route('/viewAllNotifications').post(
    (req, res) => new NotifiactionController().viewAllNotifications(req, res)
);

export default notificationRouter;