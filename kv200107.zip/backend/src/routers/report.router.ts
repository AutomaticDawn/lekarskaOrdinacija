import express from "express";
import { ReportController } from "../controllers/report.controller";

const reportRouter = express.Router();

reportRouter.route('/newReport').post(
    (req, res) => new ReportController().newReport(req, res)
);

reportRouter.route('/getReport').post(
    (req, res) => new ReportController().getReport(req, res)
);

reportRouter.route('/getAllReportsForPatient').post(
    (req, res) => new ReportController().getAllReportsForPatient(req, res)
);

export default reportRouter;