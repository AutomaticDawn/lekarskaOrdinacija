import express from "express";
import { UserController } from "../controllers/user.controller";

const userRouter = express.Router();
const uploader = require("../tools/uploader");

userRouter.route('/login').post(
    (req, res)=>new UserController().login(req, res)
);

userRouter.route('/registerPatient').post(
    uploader.single("pfp"),
    (req, res)=>new UserController().registerPatient(req, res)
);

userRouter.route('/registerDoctor').post(
    uploader.single("pfp"),
    (req, res)=>new UserController().registerDoctor(req, res)
);

userRouter.route('/validateUsernameAndEmail').post(
    (req, res)=>new UserController().validateUsernameAndEmail(req, res)
);

userRouter.route('/approveNewPatient').post(
    (req, res) => new UserController().approveNewPatient(req, res)
);

userRouter.route('/denyNewPatient').post(
    (req, res) => new UserController().denyNewPatient(req, res)
);

userRouter.route('/changePassword').post(
    (req, res) => new UserController().changePassword(req, res)
);

userRouter.route('/getPatientInfo').get(
    (req, res) => new UserController().getPatientInfo(req, res)
);

userRouter.route('/editPatientInfo').post(
    (req, res) => new UserController().editPatientInfo(req, res)
);

userRouter.route('/getDoctorInfo').get(
    (req, res) => new UserController().getDoctorInfo(req, res)
);

userRouter.route('/searchDoctors').post(
    (req, res) => new UserController().searchDoctors(req, res)
);

userRouter.route('/editDoctorInfo').post(
    (req, res) => new UserController().editDoctorInfo(req, res)
);

userRouter.route('/editPfp').post(
    uploader.single("pfp"),
    (req, res)=>new UserController().editPfp(req, res)
);

userRouter.route('/getAllPatients').get(
    (req, res) => new UserController().getAllPatients(req, res)
);

userRouter.route('/getAllUnapprovedPatients').get(
    (req, res) => new UserController().getAllUnapprovedPatients(req, res)
);

userRouter.route('/getAllDoctors').get(
    (req, res) => new UserController().getAllDoctors(req, res)
);

userRouter.route('/deleteUser').post(
    (req, res) => new UserController().deleteUser(req, res)
);

userRouter.route('/updateAppointmentTypesForDoctor').post(
    (req, res) => new UserController().updateAppointmentTypesForDoctor(req, res)
);

export default userRouter;