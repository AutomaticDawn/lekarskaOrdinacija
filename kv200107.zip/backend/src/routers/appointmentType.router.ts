import express from "express";
import { AppointmentTypeController } from "../controllers/appointmentType.controller";

const appointmentTypeRouter = express.Router();

appointmentTypeRouter.route('/addNewAppointmentTypeUnapproved').post(
    (req, res) => new AppointmentTypeController().addNewAppointmentTypeUnapproved(req, res)
);

appointmentTypeRouter.route('/addNewAppointmentTypeApproved').post(
    (req, res) => new AppointmentTypeController().addNewAppointmentTypeApproved(req, res)
);

appointmentTypeRouter.route('/approveNewAppointmentType').post(
    (req, res) => new AppointmentTypeController().approveNewAppointmentType(req, res)
);

appointmentTypeRouter.route('/denyNewAppointmentType').post(
    (req, res) => new AppointmentTypeController().denyNewAppointmentType(req, res)
);

appointmentTypeRouter.route('/editAppointmentType').post(
    (req, res) => new AppointmentTypeController().editAppointmentType(req, res)
);

appointmentTypeRouter.route('/deleteAppointmentType').post(
    (req, res) => new AppointmentTypeController().deleteAppointmentType(req, res)
);

appointmentTypeRouter.route('/getAllAppointmentTypesForSpecialization').get(
    (req, res) => new AppointmentTypeController().getAllAppointmentTypesForSpecialization(req, res)
);

appointmentTypeRouter.route('/getAllUnapprovedAppointmentTypes').get(
    (req, res) => new AppointmentTypeController().getAllUnapprovedAppointmentTypes(req, res)
);

appointmentTypeRouter.route('/getAppointmentTypes').post(
    (req, res) => new AppointmentTypeController().getAppointmentTypes(req, res)
);

export default appointmentTypeRouter;