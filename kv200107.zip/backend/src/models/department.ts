import mongoose from "mongoose";

const Schema = mongoose.Schema;

let Department = new Schema({
    name: {
        type: String
    }
});

export default mongoose.model('DepartmentModel', Department, "departments");