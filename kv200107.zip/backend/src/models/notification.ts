import mongoose from "mongoose";

const Schema = mongoose.Schema;

let Notifiaction = new Schema({
    username: {
        type: String
    },
    title: {
        type: String
    },
    content: {
        type: String
    },
    date: {
        type: Date
    },
    viewed: {
        type: Boolean
    }
});

export default mongoose.model('NotifiactionModel', Notifiaction, "notifications");