import { Binary } from "mongodb";
import mongoose from "mongoose";

const Schema = mongoose.Schema;

let User = new Schema({
    type: {
        type: Number
    },
    username: {
        type: String
    },
    password: {
        type: String
    },
    firstname:{
        type: String
    },
    lastname: {
        type: String
    },
    address: {
        type: String
    },
    phone_number: {
        type: String
    },
    email: {
        type: String
    },
    pfp: {
        type: String,
    },
    license_number: {
        type: String
    },
    specialization: {
        type: String
    },
    department: {
        type: String
    },
    approved: {
        type: Boolean
    },
    considered: {
        type: Boolean
    },
    appointment_types: {
        type: Array
    }
});

export default mongoose.model('UserModel', User, "users");