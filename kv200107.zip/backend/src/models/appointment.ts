import mongoose from "mongoose";

const Schema = mongoose.Schema;

let Appointment = new Schema({
    patient: {
        type: String
    },
    patient_firstname: {
        type: String
    },
    patient_lastname: {
        type: String
    },
    doctor: {
        type: String
    },
    doctor_firstname: {
        type: String
    },
    doctor_lastname: {
        type: String
    },
    appointment_type: {
        type: String
    },
    department: {
        type: String
    },
    start_date_and_time: {
        type: Date
    },
    end_date_and_time: {
        type: Date
    },
    performed: {
        type: Boolean
    },
    canceled: {
        type: Boolean
    },
    cancel_reason: {
        type: String
    }
});

export default mongoose.model('AppointmentModel', Appointment, "appointments");