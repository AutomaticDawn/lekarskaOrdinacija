import mongoose from "mongoose";

const Schema = mongoose.Schema;

let AppointmentType = new Schema({
    name: {
        type: String
    },
    length: {
        type: String
    },
    price: {
        type: String
    },
    specialization: {
        type: String
    },
    approved: {
        type: Boolean
    },
    deleted: {
        type: Boolean
    }
});

export default mongoose.model('AppointmentTypeModel', AppointmentType, "appointmentTypes");