import mongoose from "mongoose";

const Schema = mongoose.Schema;

let Report = new Schema({
    patient: {
        type: String
    },
    doctor: {
        type: String
    },
    date_and_time_of_appointment: {
        type: Date
    },
    doctor_name: {
        type: String
    },
    doctor_specialization: {
        type: String
    },

    reason_for_appointment: {
        type: String
    },
    diagnosis: {
        type: String
    },
    recommended_therapy: {
        type: String
    },
    next_appointment_recommended_date: {
        type: Date
    }
});

export default mongoose.model('ReportModel', Report, "reports");