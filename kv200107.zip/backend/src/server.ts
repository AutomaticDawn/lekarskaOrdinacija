import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import userRouter from './routers/user.routes';
import appointmentTypeRouter from './routers/appointmentType.router';
import specializationRouter from './routers/specialization.router';
import departmentRouter from './routers/department.router';
import appointmentRouter from './routers/appointment.router';
import reportRouter from './routers/report.router';
import notificationRouter from './routers/notification.router';


const path = require("path");
const app = express();
app.use(cors());
app.use(express.json());

app.use(express.static('src'));
app.use('/uploads', express.static(path.join(__dirname, "uploads")));

//127.0.0.1 umesto localhost ubaciti
mongoose.connect('mongodb://localhost:27017/LekarskaOrdinacija');
const connection = mongoose.connection;
connection.once('open', ()=>{
    console.log("Database connected");
});

const router = express.Router();
router.use('/users', userRouter);
router.use('/appointmentTypes', appointmentTypeRouter);
router.use('/specializations', specializationRouter);
router.use('/departments', departmentRouter);
router.use('/appointments', appointmentRouter);
router.use('/reports', reportRouter);
router.use('/notifications', notificationRouter);

app.use('/', router);
//app.get('/', (req, res) => res.send('Hello World!'));
app.listen(4000, () => console.log(`Express server running on port 4000`));