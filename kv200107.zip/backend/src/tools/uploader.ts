const path = require("path");
const multer = require('multer');

var validFileType = function(file, cb){
    //console.log(file.originalname);
    const validTypes = /jpeg|jpg|png|/;
    const fileExtName = validTypes.test(path.extname(file.originalname).toLowerCase());
    const fileMimeType = validTypes.test(file.mimetype);
    if (fileExtName && fileMimeType) return cb(null, true);
    else cb("File Type Not Supported", false);
};

var Storage = multer.diskStorage({
    destination:'src/uploads',
    filename:(req, file, cb)=>{
        let filename = Date.now() + path.extname(file.originalname);
        cb(null, filename);
    }
})

var upload = multer({
    storage: Storage,
    fileFilter: (req, file, cb)=>{
        validFileType(file, cb);
    }
});

module.exports = upload;