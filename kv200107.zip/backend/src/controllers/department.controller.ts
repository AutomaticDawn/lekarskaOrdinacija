import express from 'express';
import DepartmentModel from "../models/department";

export class DepartmentController {
    getAllDepartments = (req: express.Request, res: express.Response) => {
        //console.log("Getting all departments")
        DepartmentModel.find({}, (err, data) => {
            if(err) console.log(err)
            else res.json(data)
        });
    }
}