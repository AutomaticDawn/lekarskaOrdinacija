import express from 'express';
import SpecializationModel from "../models/specialization";

export class SpecializationController {
    addSpecialization = (req: express.Request, res: express.Response) => {
        let specialization = new SpecializationModel({
            name: req.body.name
        })

        //console.log("Adding new specialization")
        specialization.save((err, resp)=>{
            if(err) {
                console.log("Invalid Inputs For New Specialization");
                res.status(400).json({"message": "error"})
            }
            else {
                //console.log("Successful register");
                res.json({"message": "ok"});
            }
        })
    }

    getAllSpecializations = (req: express.Request, res: express.Response) => {
        //console.log("Getting all specializations")
        SpecializationModel.find({}, (err, data) => {
            if(err) console.log(err)
            else res.json(data)
        });
    }
}
