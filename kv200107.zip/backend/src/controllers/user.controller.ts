import express from 'express';
import UserModel from "../models/user";
import fs from 'fs';
import { escape } from 'querystring';

const multer  = require("multer");

export class UserController {
    login = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;
        let password = req.body.password;
  
        UserModel.findOne({'username': username, 'password': password}, (err, user)=>{
            if(err) {
                console.log("Invalid Credentials For Login");
                res.json({"message": "error"})
            }
            else {
                //console.log("Successful login");
                res.json(user);
            }
        })
    }

    registerPatient = (req: express.Request, res: express.Response)=>{
        let pfpName = req.file ? req.file.filename : "defaultPfp.jpeg";

        let user = new UserModel({
            type: 2,
            username: req.body.username,
            password: req.body.password,
            firstname: req.body.firstname,
            lastname: req.body.lastname,
            address: req.body.address,
            phone_number: req.body.phone_number,
            email: req.body.email,
            pfp: pfpName,
            license_number: null,
            specialization: null,
            department: null,
            approved: false,
            considered: false
        })

        user.save((err, resp)=>{
            if(err) {
                console.log("Invalid Credentials For Register");
                res.status(400).json({"message": "error"})
            }
            else {
                //console.log("Successful register");
                res.json({"message": "ok"});
            }
        })
    }

    registerDoctor = (req: express.Request, res: express.Response)=>{
        let pfpName = req.file ? req.file.filename : "defaultPfp.jpeg";

        let user = new UserModel({
            type: 1,
            username: req.body.username,
            password: req.body.password,
            firstname: req.body.firstname,
            lastname: req.body.lastname,
            address: req.body.address,
            phone_number: req.body.phone_number,
            email: req.body.email,
            pfp: pfpName,
            license_number: req.body.license_number,
            specialization: req.body.specialization,
            department: req.body.department,
            approved: true,
            considered: true,
            appointment_types: [],
        })

        user.save((err, resp)=>{
            if(err) {
                console.log("Invalid Credentials For Register");
                res.status(400).json({"message": "error"})
            }
            else {
                //console.log("Successful register");
                res.json({"message": "ok"});
            }
        })
    }

    validateUsernameAndEmail = (req: express.Request, res: express.Response)=>{
        let username = req.body.username;
        let email = req.body.email;

        let usernameTaken = false;
        let emailTaken = false;

        UserModel.findOne({'username': username}, (err, user)=>{
            if(err){
                console.log("Error when validating username for register");
                res.status(400).json({"message": "error"})
            }
            else if(user != null) {
                //console.log("Username Already Taken");
                usernameTaken = true;
            }

            UserModel.findOne({'email': email}, (err, user)=>{
                if(err){
                    console.log("Error when validating email for register");
                    res.status(400).json({"message": "error"})
                }
                else if(user != null) {
                    //console.log("Email Already Taken");
                    emailTaken = true;
                }

                //console.log(usernameTaken + " " + emailTaken);
                res.json({"usernameTaken": usernameTaken, "emailTaken": emailTaken});
            });
        });   
    }

    approveNewPatient = (req: express.Request, res: express.Response) => {
        UserModel.updateOne({"username": req.body.username}, {$set:{"approved": true, "considered": true}}, (err, resp) => {
            if(err) {
                console.log(err);
                res.status(400).json({"message": "error"})
            }
            else res.json({"message": "ok"})
        });
    }

    denyNewPatient = (req: express.Request, res: express.Response) => {
        UserModel.updateOne({"username": req.body.username}, {$set:{"approved": false, "considered": true}}, (err, resp) => {
            if(err) {
                console.log(err);
                res.status(400).json({"message": "error"})
            }
            else res.json({"message": "ok"})
        });
    }

    changePassword = (req: express.Request, res: express.Response) => {
        let username = req.body.username;
        let oldPassword = req.body.oldPassword;
        let newPassword = req.body.newPassword;
        UserModel.updateOne({"username": username, "password": oldPassword}, {$set:{"password": newPassword}}, (err, resp) => {
            if (err) console.log(err);
            else res.json({"message": "ok"});
        });
    }

    getPatientInfo = (req: express.Request, res: express.Response) => {
        let username = req.query.username;
        UserModel.findOne({"username": username, "type": 2}, (err, user) => {
            if(err) console.log(err)
            else res.json(user)
        });
    }

    //DODATI VALIDACIJU EMAIL ADRESE PRE PROMENE
    editPatientInfo = (req: express.Request, res: express.Response) => {
        let username = req.body.username;
        let firstname = req.body.firstname;
        let lastname = req.body.lastname
        let address = req.body.address;
        let email = req.body.email;
        let phone_number = req.body.phone_number;

        let emailEdit = req.body.emailEdit;

        if(emailEdit)
        {
            UserModel.findOne({'email': email}, (err, user)=>{
                if(err){
                    console.log("Error when validating email for editing patient info");
                    res.status(400).json({"message": "error"})
                }
                else if(user != null) {
                    res.json({"message": "email taken"});
                }
                else{
                    UserModel.updateOne({"username": username}, {$set:{"firstname": firstname, "lastname": lastname, "address": address, "email": email, "phone_number": phone_number}}, (err, resp) => {
                        if(err) {
                            console.log(err);
                            res.status(400).json({"message": "Error while updating patient info"})
                        }
                        else res.json({"message": "ok"})
                    });
                }
            });
        }
        else{
            UserModel.updateOne({"username": username}, {$set:{"firstname": firstname, "lastname": lastname, "address": address, 
            "email": email, "phone_number": phone_number}}, (err, resp) => {
                if(err) {
                    console.log(err);
                    res.status(400).json({"message": "Error while updating patient info"})
                }
                else res.json({"message": "ok"})
            });
        }
    }

    getDoctorInfo = (req: express.Request, res: express.Response) => {
        let username = req.query.username;
        UserModel.findOne({"username": username, "type": 1}, (err, user) => {
            if(err) console.log(err)
            else res.json(user)
        });
    }

    searchDoctors = (req: express.Request, res: express.Response) => {
        let firstname = req.body.firstname;
        let lastname = req.body.lastname;
        let specialization = req.body.specialization;
        UserModel.find({"firstname": { $regex: `(?i)${firstname}`}, "lastname": { $regex: `(?i)${lastname}`}, "specialization": { $regex: `(?i)${specialization}`}, "type": 1}, (err, user) => {
            if(err) console.log(err)
            else res.json(user)
        });
    }

    editDoctorInfo = (req: express.Request, res: express.Response) => {
        let username = req.body.username;
        let firstname = req.body.firstname;
        let lastname = req.body.lastname
        let address = req.body.address;
        let phone_number = req.body.phone_number;
        let email = req.body.email;
        let emailEdit = req.body.emailEdit;
        let license_number = req.body.license_number;
        let specialization = req.body.specialization;
        let specializationEdit = req.body.specializationEdit;
        let department = req.body.department;
        if(emailEdit)
        {
            UserModel.findOne({'email': email}, (err, user)=>{
                if(err){
                    console.log("Error when validating email for editing patient info");
                    res.status(400).json({"message": "error"})
                }
                else if(user != null) {
                    res.json({"message": "email taken"});
                }
                else{
                    UserModel.updateOne({"username": username}, {$set:{"firstname": firstname, "lastname": lastname, "address": address, "phone_number": phone_number, "email": email, "license_number": license_number, "specialization": specialization, "department": department}}, (err, resp) => {
                        if(err) {
                            console.log(err);
                            res.status(400).json({"message": "Error while updating doctor info"})
                        }
                        else {
                            if(specializationEdit){
                                UserModel.updateOne({"username": username}, {$set:{"appointment_types": []}}, (err, resp)=>{
                                    if(err) {
                                        console.log(err);
                                        res.status(400).json({"message": "Error while reseting appointment types in doctor"})
                                    }
                                    else res.json({"message": "ok"})
                                })
                            }
                            else res.json({"message": "ok"})
                        }
                    });
                }
            });
        }
        else{
            UserModel.updateOne({"username": username}, {$set:{"firstname": firstname, "lastname": lastname, "address": address, "email": email, 
            "phone_number": phone_number, "license_number": license_number, "specialization": specialization, "department": department}}, (err, resp) => {
                if(err) {
                    console.log(err);
                    res.status(400).json({"message": "Error while updating patient info"})
                }
                else {
                    if(specializationEdit){
                        UserModel.updateOne({"username": username}, {$set:{"appointment_types": []}}, (err, resp)=>{
                            if(err) {
                                console.log(err);
                                res.status(400).json({"message": "Error while reseting appointment types in doctor"})
                            }
                            else res.json({"message": "ok"})
                        })
                    }
                    else res.json({"message": "ok"})
                }
            });
        }
    }

    //Testirati ovo lepo
    editPfp = (req: express.Request, res: express.Response) => {
        let username = req.body.username;
        let newPfpName = req.file.filename;

        UserModel.findOneAndUpdate({"username": username}, {$set:{"pfp": newPfpName}}, {returnDocument: "before"}, (err, resp) => {
            if(err) console.log(err);
            else {
                if(resp['pfp']!=null){
                    if(resp['pfp']!="defaultPfp.jpeg") {
                        fs.unlink(`src/uploads/${resp['pfp']}`, (error) => {
                            if(error) console.log(error);
                        })
                    }    
                }
                res.json({"message": "ok", "newPfpName": req.file.filename});
            }
        });
    }

    getAllPatients = (req: express.Request, res: express.Response) => {
        UserModel.find({"type": 2, "approved": true}, (err, data) => {
            if(err) console.log(err)
            else res.json(data)
        });
    }

    getAllUnapprovedPatients = (req: express.Request, res: express.Response) => {
        UserModel.find({"type": 2, "approved": false, "considered": false}, (err, data) => {
            if(err) console.log(err)
            else res.json(data)
        });
    }

    getAllDoctors = (req: express.Request, res: express.Response) => {
        UserModel.find({"type": 1}, (err, data) => {
            if(err) console.log(err)
            else res.json(data)
        });
    }

    deleteUser = (req: express.Request, res: express.Response) => {
        UserModel.deleteOne({"username": req.body.username}, (err, resp) => {
            if(err) {
                console.log(err);
                res.status(400).json({"message": "error"})
            }
            else res.json({"message": "ok"})
        })
    }

    updateAppointmentTypesForDoctor = (req: express.Request, res: express.Response) => {
        let username = req.body.username;
        let new_appointment_types = req.body.new_appointment_types;

        UserModel.updateOne({"username": username}, {"appointment_types": new_appointment_types}, (err, resp) => {
            if(err) {
                console.log(err);
                res.status(400).json({"message": "error"})
            }
            else res.json({"message": "ok"})
        })
    }

}