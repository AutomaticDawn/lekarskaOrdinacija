import express from 'express';
import AppointmentTypeModel from "../models/appointmentType";

export class AppointmentTypeController {

    addNewAppointmentTypeUnapproved = (req: express.Request, res: express.Response) => {
        let length = req.body.length ? req.body.length : "30";
        let price = req.body.price ? req.body.price : "0";

        let appointmentType = new AppointmentTypeModel({
            name: req.body.name,
            length: length,
            price: price,
            specialization: req.body.specialization,
            approved: false,
            deleted: false,
        })

        appointmentType.save((err, resp)=>{
            if(err) {
                console.log("Invalid Inputs For New Appointment Type");
                res.status(400).json({"message": "error"})
            }
            else {
                //console.log("Successful register");
                res.json({"message": "ok"});
            }
        })
    }

    addNewAppointmentTypeApproved = (req: express.Request, res: express.Response) => {
        let length = req.body.length ? req.body.length : "30";
        let price = req.body.price ? req.body.price : "0";

        let appointmentType = new AppointmentTypeModel({
            name: req.body.name,
            length: length,
            price: price,
            specialization: req.body.specialization,
            approved: true,
            deleted: false,
        })

        appointmentType.save((err, resp)=>{
            if(err) {
                console.log("Invalid Inputs For New Appointment Type");
                res.status(400).json({"message": "error"})
            }
            else {
                //console.log("Successful register");
                res.json({"message": "ok"});
            }
        })
    }

    approveNewAppointmentType = (req: express.Request, res: express.Response) => {
        AppointmentTypeModel.updateOne({"name": req.body.name}, {$set:{"approved": true}}, (err, resp) => {
            if(err) {
                console.log(err);
                res.status(400).json({"message": "error"})
            }
            else res.json({"message": "ok"})
        });
    }

    denyNewAppointmentType = (req: express.Request, res: express.Response) => {
        AppointmentTypeModel.deleteOne({"name": req.body.name}, (err, resp) => {
            if(err) {
                console.log(err);
                res.status(400).json({"message": "error"})
            }
            else res.json({"message": "ok"})
        });
    }

    editAppointmentType = (req: express.Request, res: express.Response) => {
        let name = req.body.name;

        let length = req.body.length ? req.body.length : "30";
        let price = req.body.price ? req.body.price : "0";

        AppointmentTypeModel.updateOne({"name": name}, {$set:{"length": length, "price": price }}, (err, resp) => {
            if(err) {
                console.log(err);
                res.status(400).json({"message": "Error while updating appointment type"})
            }
            else res.json({"message": "ok"})
        });
    }

    deleteAppointmentType = (req: express.Request, res: express.Response) => {
        AppointmentTypeModel.updateOne({"name": req.body.name}, {$set:{"deleted": true}}, (err, resp) => {
            if(err) {
                console.log(err);
                res.status(400).json({"message": "error"})
            }
            else res.json({"message": "ok"})
        });
    }

    getAllAppointmentTypesForSpecialization = (req: express.Request, res: express.Response) => {
        AppointmentTypeModel.find({"specialization": req.query.specialization, "approved": true, "deleted": false}, (err, data) => {
            if(err) console.log(err)
            else res.json(data)
        });
    }

    getAllUnapprovedAppointmentTypes = (req: express.Request, res: express.Response) => {
        AppointmentTypeModel.find({"approved": false, "deleted": false}, (err, data) => {
            if(err) console.log(err)
            else res.json(data)
        });
    }

    getAppointmentTypes = (req: express.Request, res: express.Response) => {
        let at = req.body.appointment_types;
        AppointmentTypeModel.find({"name": {"$in":at},"approved": true, "deleted": false}, (err, data) => {
            if(err) console.log(err)
            else res.json(data)
        });
    }
}