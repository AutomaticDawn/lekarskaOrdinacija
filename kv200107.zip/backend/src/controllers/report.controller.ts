import express from 'express';
import ReportModel from "../models/report";
import AppointmentModel from "../models/appointment";

export class ReportController {
    newReport = (req: express.Request, res: express.Response) => {
        let report = new ReportModel({
            patient: req.body.patient,
            doctor: req.body.doctor,

            date_and_time_of_appointment: req.body.date_and_time_of_appointment,
            doctor_name: req.body.doctor_name,
            doctor_specialization: req.body.doctor_specialization,
            reason_for_appointment: req.body.reason_for_appointment,
            diagnosis: req.body.diagnosis,
            recommended_therapy: req.body.recommended_therapy,
            next_appointment_recommended_date: req.body.next_appointment_recommended_date
        })

        AppointmentModel.updateOne({"patient": req.body.patient, "doctor": req.body.doctor, "start_date_and_time": req.body.date_and_time_of_appointment},{$set:{"performed": true}}, (err, data) => {
            if(err) console.log(err)
            else {
                report.save((err, resp)=>{
                    if(err) {
                        res.status(400).json({"message": "error"})
                    }
                    else {
                        res.json({"message": "ok"});
                    }
                })
            }
        });
    }

    getReport = (req: express.Request, res: express.Response) => {
        let patient = req.body.patient;
        let doctor = req.body.doctor;
        let date_and_time_of_appointment = req.body.date_and_time_of_appointment;

        //console.log(patient + " " + doctor + " " + date_and_time_of_appointment)
        ReportModel.findOne({"patient": patient, "doctor": doctor, "date_and_time_of_appointment": date_and_time_of_appointment}, (err, data) => {
            if(err) console.log(err)
            else {
                //console.log("Found report: " + data[0]['diagnosis'])
                res.json(data)
            }
        });
    }
    
    getAllReportsForPatient = (req: express.Request, res: express.Response) => {
        let patient = req.body.patient;

        ReportModel.find({"patient": patient}, (err, data) => {
            if(err) console.log(err)
            else res.json(data)
        });
    }

}