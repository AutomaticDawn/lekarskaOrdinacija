import express from 'express';
import NotifiactionModel from "../models/notification";

export class NotifiactionController {
    getAllUnviewedNotifiactionsForUser = (req: express.Request, res: express.Response) => {
        let username = req.body.username;

        NotifiactionModel.find({"username": username, "viewed": false}, (err, data) => {
            if(err) console.log(err)
            else res.json(data)
        });
    }

    getAllViewedNotifiactionsForUser = (req: express.Request, res: express.Response) => {
        let username = req.body.username;

        NotifiactionModel.find({"username": username, "viewed": true}, (err, data) => {
            if(err) console.log(err)
            else res.json(data)
        });
    }

    createNotification = (req: express.Request, res: express.Response) => {
        let notification = new NotifiactionModel({
            username: req.body.username,
            title: req.body.title,
            content: req.body.content,
            date: new Date(),
            viewed: false
        })

        notification.save((err, resp)=>{
            if(err) {
                console.log("Invalid Inputs For New Notification");
                res.status(400).json({"message": "error"})
            }
            else {
                //console.log("Successful register");
                res.json({"message": "ok"});
            }
        })
    }

    viewAllNotifications = (req: express.Request, res: express.Response) => {
        let username = req.body.username;

        NotifiactionModel.updateMany({"username": username, "viewed": false},{$set:{"viewed": true}}, (err, data) => {
            if(err) res.status(400).json({"message": "error"})
            else res.json({"message": "ok"})
        });
    }
}