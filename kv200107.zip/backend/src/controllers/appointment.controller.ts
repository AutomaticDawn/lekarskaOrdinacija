import express from 'express';
import AppointmentModel from "../models/appointment";
import moment from 'moment';

export class AppointmentController {
    newAppointment = (req: express.Request, res: express.Response) => {
        let start = moment(req.body.start_date_and_time).add(2, "h").toDate();
        let end = moment(req.body.end_date_and_time).add(2, "h").toDate();

        let appointment = new AppointmentModel({
            patient: req.body.patient,
            patient_firstname: req.body.patient_firstname,
            patient_lastname: req.body.patient_lastname,
            doctor: req.body.doctor,
            doctor_firstname: req.body.doctor_firstname,
            doctor_lastname: req.body.doctor_lastname,
            appointment_type: req.body.appointment_type,
            department: req.body.department,
            start_date_and_time: start,
            end_date_and_time: end,
            performed: false,
            canceled: false,
            cancelReason: "",
        })

        //console.log(start)

        AppointmentModel.find({"doctor": req.body.doctor, "start_date_and_time":{$gte: req.body.start_date_and_time, $lt: req.body.end_date_and_time}, "canceled": false}, (err, data)=>{
            if(err){
                console.log(err)
            }
            else if(data.length == 0){
                AppointmentModel.find({"doctor": req.body.doctor, "end_date_and_time":{$gte: req.body.start_date_and_time, $lt: req.body.end_date_and_time}, "canceled": false}, (err, data)=>{
                    if(err){
                        console.log(err)
                    }
                    else if(data.length == 0){
                        appointment.save((err, resp)=>{
                            if(err) {
                                res.status(400).json({"message": "error"})
                            }
                            else {
                                res.json({"message": "ok"});
                            }
                        })
                    }
                    else{
                        res.json({"message": "not available"})
                    }
                })
            }
            else{
                res.json({"message": "not available"})
            }
        })
    }

    getAppointmentsUpcomingForPatient = (req: express.Request, res: express.Response) => {
        let patient = req.body.patient;
        AppointmentModel.find({"patient": patient, "performed": false, "canceled": false}, (err, data) => {
            if(err) console.log(err)
            else res.json(data)
        });
    }

    getAppointmentsFinishedForPatient = (req: express.Request, res: express.Response) => {
        let patient = req.body.patient;
        AppointmentModel.find({"patient": patient, "performed": true, "canceled": false}, (err, data) => {
            if(err) console.log(err)
            else res.json(data)
        });
    }

    getAppointmentsUpcomingForDoctor = (req: express.Request, res: express.Response) => {
        let doctor = req.body.doctor;

        let now = new Date();
        now = moment(now).add(2, "h").toDate();

        AppointmentModel.find({"doctor": doctor, "end_date_and_time": {$gt: now}, "performed": false, "canceled": false}, (err, data) => {
            if(err) console.log(err)
            else res.json(data)
        });
    }

    getAppointmentsFinishedForDoctor = (req: express.Request, res: express.Response) => {
        let doctor = req.body.doctor;

        AppointmentModel.find({"doctor": doctor, "performed": true, "canceled": false}, (err, data) => {
            if(err) console.log(err)
            else res.json(data)
        });
    }

    cancelAppointment = (req: express.Request, res: express.Response) => {
        let doctor = req.body.doctor;
        let start_date_and_time = req.body.start_date_and_time;
        let cancel_reason = req.body.cancel_reason;

        AppointmentModel.updateOne({"doctor": doctor, "start_date_and_time": start_date_and_time, "performed": false},{$set:{"canceled": true, "cancel_reason": cancel_reason}}, (err, data) => {
            if(err) console.log(err)
            else res.json({"message": "ok"})
        });
    }

    performAppointment = (req: express.Request, res: express.Response) => {
        let patient = req.body.patient;
        let doctor = req.body.doctor;
        let start_date_and_time = req.body.start_date_and_time;

        AppointmentModel.updateOne({"patient": patient, "doctor": doctor, "start_date_and_time": start_date_and_time},{$set:{"performed": true}}, (err, data) => {
            if(err) console.log(err)
            else res.json({"message": "ok"})
        });
    }

    //za patient record

    getPerformedAppointments = (req: express.Request, res: express.Response) => {
        let patient = req.body.patient;
        AppointmentModel.find({"patient": patient, "performed": true, "canceled": false}, (err, data) => {
            if(err) console.log(err)
            else res.json(data)
        });
    }

    getCurrentAppointment = (req: express.Request, res: express.Response) => {
        let patient = req.body.patient;
        let doctor = req.body.doctor;

        let now = new Date();
        now = moment(now).add(2, "h").toDate();

        AppointmentModel.find({"patient": patient, "doctor": doctor, "start_date_and_time":{$lt: now}, "end_date_and_time":{$gte: now}, "performed": false, "canceled": false}, (err, data) => {
            if(err) console.log(err)
            else res.json(data)
        });
    }

    getPastAppointmentsWithoutReport = (req: express.Request, res: express.Response) => {
        let patient = req.body.patient;
        let doctor = req.body.doctor;

        let now = new Date();
        now = moment(now).add(2, "h").toDate();

        AppointmentModel.find({"patient": patient, "doctor": doctor, "end_date_and_time":{$lt: now}, "performed": false, "canceled": false}, (err, data) => {
            if(err) console.log(err)
            else res.json(data)
        });
    }
}
